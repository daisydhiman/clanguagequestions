// 1 . Write a program to show that example of pre-increment ?

#include <stdio.h>

int main(){
    int  a =5;
    printf("Value befor pre increment is : %d\n",a);
    printf("Value during pre increment is : %d\n",++a);
    printf("Value After pre increment is : %d",a);

    return 0;
}