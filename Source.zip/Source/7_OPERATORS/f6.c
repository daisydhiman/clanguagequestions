// 6 . 6. Write a program to enter a number from the user ,the length of the number is depend on the user ,programmer should print the last digit of number ?

#include <stdio.h>

int main(){
    int a;
    printf("Enter the number : ");
    scanf("%d",&a);
    printf("The last digit of number is : %d", a%10);


    return 0; 
}