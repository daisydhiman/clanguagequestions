// 9. Enter float number from user and round of the number ?


#include <stdio.h>

int main() {
    float a; int rounded;
    printf("Enter a decimal num ber : ");
    scanf("%f", &a);

    rounded = (int)(a + 0.5);
    if (a < 0)
        rounded = (int)(a - 0.5);

    printf("Round off of %f is  : %d\n",a, rounded);

    return 0;
}
