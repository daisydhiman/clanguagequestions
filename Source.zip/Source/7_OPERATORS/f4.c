// 4. Write a program to show example of post-decrement ?

#include <stdio.h>

int main(){
    int a = 5;

    printf("Value before post-decrement : %d\n", a);
    printf("Value during post-decrement : %d\n", a--);
    printf("Value after post-decrement  : %d\n", a);

    return 0;
}
