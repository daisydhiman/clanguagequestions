// 2. Write a program to show example of post-increment ?

#include <stdio.h>

int main(){
    int a = 5;

    printf("Value before post-increment : %d\n", a);
    printf("Value during post-increment : %d\n", a++);
    printf("Value after post-increment  : %d\n", a);

    return 0;
}
