// 10. Enter a lower case character from user and print it into upper case ?


# include <stdio.h>
#include <conio.h>

int main(){
    char a;

    printf("Enter the charachter : ");
    a=getche();
    if (a>=97 && a<=122){
        printf("\nThe char %c in Upparcase is %c",a,a-32);
    }
    else
    printf("\nEnter a lowercase char");


    return  0;
}