// 7. Enter a decimal number from the user (float) and print the right hand side of the decimal point ?

#include <stdio.h>

int main() {
    float a;
    int b;
    printf("Enter a decimal number : ");
    scanf("%f", &a);
    b = a;
    printf("The decimal points of %f is  : %f ", a,a - b);
    return 0;
}
