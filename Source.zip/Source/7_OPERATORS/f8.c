// 8. Enter a number from user and find out cube of numbers ?


#include <stdio.h>

int main(){
    int a;
    printf("Enter the number : ");
    scanf("%d",&a);
    printf("The CUBE of number is : %d", a*a*a);


    return 0; 
}