// 3. Write a program to show example of pre-decrement ?

#include <stdio.h>

int main(){
    int a = 5;

    printf("Value before pre-decrement : %d\n", a);
    printf("Value during pre-decrement : %d\n", --a);
    printf("Value after pre-decrement  : %d\n", a);

    return 0;
}
