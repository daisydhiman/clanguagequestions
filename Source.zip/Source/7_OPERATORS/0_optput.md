# OUTPUTS BASIC INPUT OUTPUT 
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
// 1 . Write a program to show that example of pre-increment ?

#include <stdio.h>

int main(){
    int  a =5;
    printf("Value befor pre increment is : %d\n",a);
    printf("Value during pre increment is : %d\n",++a);
    printf("Value After pre increment is : %d",a);

    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f1.c -o f1; .\f1          
Value befor pre increment is : 5
Value during pre increment is : 6
Value After pre increment is : 6

```

---

## 2. 
```c
// 2. Write a program to show example of post-increment ?

#include <stdio.h>

int main(){
    int a = 5;

    printf("Value before post-increment : %d\n", a);
    printf("Value during post-increment : %d\n", a++);
    printf("Value after post-increment  : %d\n", a);

    return 0;
}

OUTPUT


PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f2.c -o f2; .\f2
Value before post-increment : 5
Value during post-increment : 5
Value after post-increment  : 6
```

---

## 3.
```c
// 3. Write a program to show example of pre-decrement ?

#include <stdio.h>

int main(){
    int a = 5;

    printf("Value before pre-decrement : %d\n", a);
    printf("Value during pre-decrement : %d\n", --a);
    printf("Value after pre-decrement  : %d\n", a);

    return 0;
}


OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f3.c -o f3; .\f3
Value before pre-decrement : 5
Value during pre-decrement : 4
Value after pre-decrement  : 4

```
---

## 4. 
```c
// 4. Write a program to show example of post-decrement ?

#include <stdio.h>

int main(){
    int a = 5;

    printf("Value before post-decrement : %d\n", a);
    printf("Value during post-decrement : %d\n", a--);
    printf("Value after post-decrement  : %d\n", a);

    return 0;
}



OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f4.c -o f4; .\f4
Value before post-decrement : 5
Value during post-decrement : 5
Value after post-decrement  : 4

```

---

## 5 .

```c
// 5 . Write a program to enter 2 numbers from user add the number and show the answer , 
// again take 2 number from user subtract the number display the answer ,
// again take 2 number from user multiply the number display the answer and ,
// again take 2 number from the user divide the number display the answer ,
// again take 2 number find the remainder and display the answer ?


#include <stdio.h>

int main(){
    int a, b;

    printf("Enter first number for Addition : ");
    scanf("%d", &a);
    printf("Enter second number for Addition : ");
    scanf("%d", &b);
    printf("Sum = %d\n\n", a + b);

    printf("Enter first number for Subtraction : ");
    scanf("%d", &a);
    printf("Enter second number for Subtraction : ");
    scanf("%d", &b);
    printf("Difference = %d\n\n", a - b);

    printf("Enter first number for Multiply : ");
    scanf("%d", &a);
    printf("Enter second number for Multiply : ");
    scanf("%d", &b);
    printf("Product = %d\n\n", a * b);


    printf("Enter first number for Division : ");
    scanf("%d", &a);
    printf("Enter second number for Division : ");
    scanf("%d", &b);

    b != 0 ? printf("Quotient = %d\n\n", a / b) : printf("Division by ZERO not allowed\n\n");
    
    printf("Enter first number for Remainder : ");
    scanf("%d", &a);
    printf("Enter second number for remainder : ");
    scanf("%d", &b);

    b != 0 ? printf("Remainder = %d\n", a % b) : printf("Division by ZERO not allowed\n\n");

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f5.c -o f5; .\f5
Enter first number for Addition : 232
Enter second number for Addition : 32
Sum = 264

Enter first number for Subtraction : 232
Enter second number for Subtraction : 3
Difference = 229

Enter first number for Multiply : 232
Enter second number for Multiply : 4
Product = 928

Enter first number for Division : 43
Enter second number for Division : 2
Quotient = 21

Enter first number for Remainder : 3434
Enter second number for remainder : 44
Remainder = 2

```
## 6. 

```c
// 6. Write a program to enter a number from the user ,the length of the number is depend on the user ,programmer should print the last digit of number ?

#include <stdio.h>

int main(){
    int a;
    printf("Enter the number : ");
    scanf("%d",&a);
    printf("The last digit of number is : %d", a%10);


    return 0; 
}


OUTPUT 


PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f6.c -o f6; .\f6
Enter the number : 342423
The last digit of number is : 3



```

---
## 7. 

```c

// 7. Enter a decimal number from the user (float) and print the right hand side of the decimal point ?

#include <stdio.h>

int main() {
    float a;
    int b;
    printf("Enter a decimal number : ");
    scanf("%f", &a);
    b = a;
    printf("The decimal points of %f is  : %f ", a,a - b);
    return 0;
}


OUTPUTS

PS E:\dx\Coding\C_4205_BCA\source\7_operators> gcc f7.c -o f7; .\f7
Enter a decimal number : 34.3434324
The decimal points of 34.343433 is  : 0.343433 


```


---

## 8. 

```c

// 8. Enter a number from user and find out cube of numbers ?


#include <stdio.h>

int main(){
    int a;
    printf("Enter the number : ");
    scanf("%d",&a);
    printf("The CUBE of number is : %d", a*a*a);


    return 0; 
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f8.c -o f8; .\f8
Enter the number : 34
The CUBE of number is : 39304


```

----


## 9. 

```c
// 9. Enter float number from user and round of the number ?


#include <stdio.h>

int main() {
    float a; int rounded;
    printf("Enter a decimal num ber : ");
    scanf("%f", &a);

    rounded = (int)(a + 0.5);
    if (a < 0)
        rounded = (int)(a - 0.5);

    printf("Round off of %f is  : %d\n",a, rounded);

    return 0;
}


OUTPUT 


PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f9.c -o f9; .\f9
Enter a decimal num ber : 343443.677
Round off of 343443.687500 is  : 343444
PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f9.c -o f9; .\f9
Enter a decimal num ber : -86868.909
Round off of -86868.906250 is  : -86869


```
---

## 10. 

```c

// 10. Enter a lower case character from user and print it into upper case ?


# include <stdio.h>
#include <conio.h>

int main(){
    char a;

    printf("Enter the charachter : ");
    a=getche();
    if (a>=97 && a<=122){
        printf("\nThe char %c in Upparcase is %c",a,a-32);
    }
    else
    printf("\nEnter a lowercase char");


    return  0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f10.c -o f10; .\f10
Enter the charachter : D
Enter a lowercase char
PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f10.c -o f10; .\f10
Enter the charachter : d
The char d in Upparcase is D


```
---


## 11. 

```c

// 11. Enter marks of students and calculate average of student’s marks ?

#include <stdio.h>

int main(){

    float marks[5],sum=0;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the marks of subject number %d : ",i+1);
        scanf("%f",&marks[i]);
        sum+=marks[i];
    }
    printf("The average of marks is : %.2f",sum/5);


return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f11.c -o f11; .\f11
Enter the marks of subject number 1 : 5
Enter the marks of subject number 2 : 5
Enter the marks of subject number 3 : 5
Enter the marks of subject number 4 : 5
Enter the marks of subject number 5 : 5
The average of marks is : 5.00

```

---

## 12 .

```c

// 12. Calculate simple interest = (P x R x T)/ 100


#include <stdio.h>

int main() {
    float p, r, t;

    printf("Enter Principal  : ");
    scanf("%f", &p);
    printf("Enter Rate : ");
    scanf("%f", &r);
    printf("Enter Time : ");
    scanf("%f", &t);

    printf("Simple Interest :  %f\n", (p * r * t) / 100 );

    return 0;
}


OUTPUT


PS D:\dx\Coding\C_4205_BCA\source\7_operators> gcc f12.c -o f12; .\f12
Enter Principal  : 323
Enter Rate : 3
Enter Time : 3
Simple Interest :  29.070000


```
----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---