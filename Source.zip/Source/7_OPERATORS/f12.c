// 12. Calculate simple interest = (P x R x T)/ 100


#include <stdio.h>

int main() {
    float p, r, t;

    printf("Enter Principal  : ");
    scanf("%f", &p);
    printf("Enter Rate : ");
    scanf("%f", &r);
    printf("Enter Time : ");
    scanf("%f", &t);

    printf("Simple Interest :  %f\n", (p * r * t) / 100 );

    return 0;
}
