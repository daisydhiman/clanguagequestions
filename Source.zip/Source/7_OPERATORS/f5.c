// 5 . Write a program to enter 2 numbers from user add the number and show the answer , 
// again take 2 number from user subtract the number display the answer ,
// again take 2 number from user multiply the number display the answer and ,
// again take 2 number from the user divide the number display the answer ,
// again take 2 number find the remainder and display the answer ?


#include <stdio.h>

int main(){
    int a, b;

    printf("Enter first number for Addition : ");
    scanf("%d", &a);
    printf("Enter second number for Addition : ");
    scanf("%d", &b);
    printf("Sum = %d\n\n", a + b);

    printf("Enter first number for Subtraction : ");
    scanf("%d", &a);
    printf("Enter second number for Subtraction : ");
    scanf("%d", &b);
    printf("Difference = %d\n\n", a - b);

    printf("Enter first number for Multiply : ");
    scanf("%d", &a);
    printf("Enter second number for Multiply : ");
    scanf("%d", &b);
    printf("Product = %d\n\n", a * b);


    printf("Enter first number for Division : ");
    scanf("%d", &a);
    printf("Enter second number for Division : ");
    scanf("%d", &b);

    b != 0 ? printf("Quotient = %d\n\n", a / b) : printf("Division by ZERO not allowed\n\n");
    
    printf("Enter first number for Remainder : ");
    scanf("%d", &a);
    printf("Enter second number for remainder : ");
    scanf("%d", &b);

    b != 0 ? printf("Remainder = %d\n", a % b) : printf("Division by ZERO not allowed\n\n");

    return 0;
}
