// 11. Enter marks of students and calculate average of student’s marks ?

#include <stdio.h>

int main(){

    float marks[5],sum=0;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the marks of subject number %d : ",i+1);
        scanf("%f",&marks[i]);
        sum+=marks[i];
    }
    printf("The average of marks is : %.2f",sum/5);


return 0;
}