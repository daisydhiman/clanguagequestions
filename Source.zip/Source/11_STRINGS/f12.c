// 12 . Enter the string from user and copy reverse order into another string ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[50],revcpy[50]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);
    
    for (int i = 0; i < len; i++) {
        revcpy[i] = str[len - 1 - i];
    }
    revcpy[len]=0;
    printf("The REVERSE of String that you entered is : %s",revcpy);

    return 0;
}