// 19 . Enter the data from user the data consist of roll no. ,name ,class , marks of 5 subjects ?
#include <stdio.h>
#include <string.h>

int main(){
    int size = 5;

    struct datatem {
        char roll[8];
        char name[51];
        char class[10];
        int marks[5];
    };

    struct datatem stddata[size];

    for (int i = 0; i < size; i++) {

        printf("Enter the Records of students :\n");
        printf("------------------------------------\n");

        printf("Record Number : %d\n", i + 1);

        printf("Enter the Roll no : ");
        gets(stddata[i].roll);
        fflush(stdin);

        printf("Enter the Name of Student : ");
        gets(stddata[i].name);
        fflush(stdin);

        printf("Enter the Class : ");
        gets(stddata[i].class);
        fflush(stdin);

        for (int j = 0; j < 5; j++) {
            printf("Enter Marks of Subject %d : ", j + 1);
            scanf("%d", &stddata[i].marks[j]);
        }
        fflush(stdin);

        printf("--------------------------------------\n");
    }

    printf("\n=== Student Records ===\n");
    printf("\n----------------------------------\n");

    for (int i = 0; i < size; i++) {
        printf("\nStudent Record number %d:\n", i + 1);
        printf("\n----------------------------------\n\n");
        printf("Roll                : %s\n", stddata[i].roll);
        printf("Name                : %s\n", stddata[i].name);
        printf("Class               : %s\n", stddata[i].class);
        printf("Marks               : ");
        for (int j = 0; j < 5; j++) {
            printf("%d ", stddata[i].marks[j]);
        }
        printf("\n----------------------------------\n");
    }

    return 0;
}
