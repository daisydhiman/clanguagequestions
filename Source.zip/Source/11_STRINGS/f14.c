// 1 4 . Enter the string from user and enter a character , it is exist or not ?

#include <stdio.h>
#include <string.h>

int main() {
    char str[100], ch;
    int len,found=0;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);
    printf("Enter The Char : ");
    scanf("%c",&ch);


    for (int i = 0; i < len; i++) {
        if (str[i] == ch) {
            found = 1;
            break;
        }
    }

    if (found)
        printf("Yes '%c' is present in \"%s\".", ch, str);
    else
        printf("No '%c' is not present in \"%s\".", ch, str);


    return 0;
}
