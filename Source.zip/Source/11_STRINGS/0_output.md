# STRINGS
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
// 1. Enter a string from user and convert in uppercase ?  

#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){
        if (str[i]>=97 && str[i]<=122)
        str[i]= str[i]-32;
    }

    printf("Now the string is %s" , str);

    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f1.c -o f1; .\f1   
Enter the String :hello world
Now the string is HELLO WORLD

```

---

## 2. 
```c
// 2 . Enter a string from user and convert into lowercase ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){
        if (str[i]>=65 && str[i]<=80)
        str[i]= str[i]+32;
    }

    printf("Now the string is %s" , str);

    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f2.c -o f2; .\f2
Enter the String :HELLOO
Now the string is helloo

```

---

## 3.
```c
// 3 . Enter a string from user and convert into sentence case ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    if (str[0]>=97 && str[0]<=122) str[0]-=32 ; 

    for (int i=1 ; i<len ; i++){
        if (str[i]>=65 && str[i]<=80)
        str[i]= str[i]+32;
    }

    printf("The String in sentence case is :  %s" , str);

    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f3.c -o f3; .\f3
Enter the String :APPLE ManGO ICe
The String in sentence case is :  Apple mango ice

```
---

## 4. 
```c
// 4 . Enter a string from user and convert into title case ?


#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len,flag=1;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){

        if (str[i]==32) flag=1 ;  
        
        if (flag && (str[i]>=97 && str[i]<=122) ) {
        str[i]-=32 ;
        flag=0; } 

        else if (!flag && (str[i]>=65 && str[i]<=80))
        str[i]= str[i]+32;
    }

    printf("The String in Title case is :  %s" , str);

    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f4.c -o f4; .\f4
Enter the String :apple mango ice
The String in Title case is :  Apple Mango Ice

```

---

## 5 .

```c
// 5 . Enter a string from user and convert into toggle case ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){ 
        
        if (str[i]>=97 && str[i]<=122) 
        str[i]-=32;

        else if (str[i]>=65 && str[i]<=80)
        str[i]+=32;
    }

    printf("The String in Toggle case is :  %s" , str);

    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f5.c -o f5; .\f5   
Enter the String :APPle ManGO ICe
The String in Toggle case is :  appLE mANgo icE

```

---
## 6. 

```c
// 6. Enter a string from user and final length of the string ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20];
    printf("Enter the String :");
    gets(str);
    printf("The String Length is :  %d" , strlen(str));

    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f6.c -o f6; .\f6
Enter the String :Apple Mango ice
The String Length is :  15

```

----
## 7. 

```c
// 7 . Enter a string from user and compare those string ?

#include <stdio.h>
#include <string.h>

int main() {
    char str1[50], str2[50];

    printf("Enter First String : ");
    gets(str1);
    printf("Enter Second String : ");
    gets(str2);

    if (strcmp(str1, str2) == 0)
        printf("Both strings are SAME");
    else
        printf("Strings are DIFFERENT");

    return 0;
}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f7.c -o f7; .\f7   
Enter First String : Apple 
Enter Second String : Appleee
Strings are DIFFERENT


```

---

## 8. 

```c
// 8 . Enter a string from user and concatenate the string ?


#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[50];

    printf("Enter First String : ");
    gets(str1);

    printf("Enter Second String : ");
    gets(str2);

    strcat(str1, str2);

    printf("After Concatenation : %s", str1);

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f8.c -o f8; .\f8   
Enter First String : Hello Worls
Enter Second String : Apple Mango 
After Concatenation : Hello WorlsApple Mango 

```

---

## 9. 

```c
// 9 . Enter a string from user and copy that string into another string ?

#include <stdio.h>
#include <string.h>

int main() {
    char str[100], cpy[100];

    printf("Enter Thr String To be COPIED : ");
    gets(str);

    strcpy(cpy, str);

    printf("Copy of String 1 is : %s", cpy);

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f9.c -o f9; .\f9   
Enter Thr String To be COPIED : Apple Mango 
Copy of String 1 is : Apple Mango 

```

----

## 10. 
```c
// 10 . Enter the string from user ,enter a number from user ,if the user enter 0 then you will print first character of string ,
//if the user enter 1 then you will print second character of string ,if user enter 2 then you will print third character of string ,
//if user enter 3 then you point fourth character of string and if out of string then you will print out of bound ?

#include <stdio.h>
#include <string.h>

int main(){
    char str[100];
    int n, len;

    printf("Enter the String : ");
    gets(str);

    len = strlen(str);

    printf("Enter the Number : ");
    scanf("%d", &n);

    if (n >= 0 && n < len)
        printf("Character at position %d is : %c", n, str[n]);
    else
        printf("Out of Bound");

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f10.c -o f10; .\f10
Enter the String : Apple Mango
Enter the Number : 6
Character at position 6 is : M

```

----
## 11.

```c
// 11 . Enter the string from user and print each character in new line ?

#include <stdio.h>
#include <string.h>

int main() {
    char str[50] ; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);
    for (int i=0 ; i<len ; i++){
        printf("%c\n",str[i]);
    }

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f11.c -o f11; .\f11
Enter the String :ApplE
A
p
p
l
E

```
----

## 12. 

```c
// 12 . Enter the string from user and copy reverse order into another string ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[50],revcpy[50]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);
    
    for (int i = 0; i < len; i++) {
        revcpy[i] = str[len - 1 - i];
    }
    revcpy[len]=0;
    printf("The REVERSE of String that you entered is : %s",revcpy);

    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f12.c -o f12; .\f12
Enter the String :APPle MangO
The REVERSE of String that you entered is : OgnaM elPPA


```

----
## 13.

```c
// 13 . Enter two string from user and print difference each character ?

#include <stdio.h>
#include <string.h>

int main(){
    char str1[100], str2[100];
    int len1,len2,minlen;

    printf("Enter First String : ");
    gets(str1);
    len1=strlen(str1);
    printf("Enter Second String : ");
    gets(str2);
    len2=strlen(str2);
    minlen= len1<len2? len1 : len2 ;

    for (int i =0 ; i<minlen ; i++ ){
        printf("\nThe ASCII difference of %c and %c is : %d",str1[i],str2[i],str1[i]-str2[i]);
    }


    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f13.c -o f13; .\f13
Enter First String : Apple
Enter Second String : Mangooo

The ASCII difference of A and M is : -12
The ASCII difference of p and a is : 15
The ASCII difference of p and n is : 2
The ASCII difference of l and g is : 5
The ASCII difference of e and o is : -10

```

----

## 14. 
```c
// 1 4 . Enter the string from user and enter a character , it is exist or not ?

#include <stdio.h>
#include <string.h>

int main() {
    char str[100], ch;
    int len,found=0;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);
    printf("Enter The Char : ");
    scanf("%c",&ch);


    for (int i = 0; i < len; i++) {
        if (str[i] == ch) {
            found = 1;
            break;
        }
    }

    if (found)
        printf("Yes '%c' is present in \"%s\".", ch, str);
    else
        printf("No '%c' is not present in \"%s\".", ch, str);


    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f14.c -o f14; .\f14
Enter The String : Apple Mano
Enter The Char : a
Yes 'a' is present in "Apple Mano".

```

---
## 15 .

```c
// 15 . Enter the string from user and enter a character if it is exist then print the bound number ?


#include <stdio.h>
#include <string.h>

int main() {
    char str[100], ch;
    int len,found=0,i;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);
    printf("Enter The Char : ");
    scanf("%c",&ch);


    for (i = 0; i < len; i++) {
        if (str[i] == ch) {
            found = 1;
            break;
        }
    }

    if (found)
        printf("Yes '%c' is present in \"%s\". and bound number is %d", ch, str,i);
    else
        printf("No '%c' is not present in \"%s\".", ch, str);


    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f15.c -o f15; .\f15
Enter The String : hello 
Enter The Char : a
No 'a' is not present in "hello ".

```
---

## 16. 
```c
// 16 . Enter the string from user and count all vowels ?


#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int count=0,len;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);

    for (int i=0; i <len ; i++){

        switch (str[i]){
            case 'a':
            count++;
            break;
            case 'e':
            count++;
            break;
            case 'i':
            count++;
            break;
            case 'o':
            count++;
            break;
            case 'u':
            count++;
            break;
            case 'A':
            count++;
            break;
            case 'E':
            count++;
            break;
            case 'I':
            count++;
            break;
            case 'O':
            count++;
            break;
            case 'U':
            count++;
            break;
        }
        
    }

    printf ("The number of vowels in %s is %d",str,count);

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f16.c -o f16; .\f16
Enter The String : Apple Mango ICE
The number of vowels in Apple Mango ICE is 6

```

---

## 17. 
```c

// 17 . Enter the string from user and enter bound number and print character on that bound ?




#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int len,bound;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);
    printf("Enter the bound number :");
    scanf("%d",&bound);
    if (bound<=len && bound>0)
    printf("The Char that is bounded to %d is : %c",bound,str[bound-1]);
    else printf("Enter a valid bound Number");


    return 0;
}


OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f17.c -o f17; .\f17
Enter The String : Hello World
Enter the bound number :7
The Char that is bounded to 7 is : W


```

----

## 18 . 

```c
// 18 . String palindrome example (using reverse) ?


#include <stdio.h>
#include <string.h>

int main() {
    char str[100], rev[100];
    int len, i, j, isPalindrome = 1;
    printf("Enter the string : ");
    gets(str);
    len = strlen(str);


    for (i = 0, j = len - 1; i < len; i++, j--) {
        rev[i] = str[j];
    }
    rev[len] = '\0'; 

    for (i = 0; i < len; i++) {
        if (str[i] != rev[i]) {
            isPalindrome = 0;
            break;
        }
    }

    if (isPalindrome)
        printf("%s is a Palindrome", str);
    else
        printf("%s is Not a palindrome", str);

    return 0;
}


OUTPUT 


PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f18.c -o f18; .\f18
Enter the string : eeelllooollleee
eeelllooollleee is a Palindrome


```

---

## 19.

```c

// 19 . Enter the data from user the data consist of roll no. ,name ,class , marks of 5 subjects ?
#include <stdio.h>
#include <string.h>

int main(){
    int size = 5;

    struct datatem {
        char roll[8];
        char name[51];
        char class[10];
        int marks[5];
    };

    struct datatem stddata[size];

    for (int i = 0; i < size; i++) {

        printf("Enter the Records of students :\n");
        printf("------------------------------------\n");

        printf("Record Number : %d\n", i + 1);

        printf("Enter the Roll no : ");
        gets(stddata[i].roll);
        fflush(stdin);

        printf("Enter the Name of Student : ");
        gets(stddata[i].name);
        fflush(stdin);

        printf("Enter the Class : ");
        gets(stddata[i].class);
        fflush(stdin);

        for (int j = 0; j < 5; j++) {
            printf("Enter Marks of Subject %d : ", j + 1);
            scanf("%d", &stddata[i].marks[j]);
        }
        fflush(stdin);

        printf("--------------------------------------\n");
    }

    printf("\n=== Student Records ===\n");
    printf("\n----------------------------------\n");

    for (int i = 0; i < size; i++) {
        printf("\nStudent Record number %d:\n", i + 1);
        printf("\n----------------------------------\n\n");
        printf("Roll                : %s\n", stddata[i].roll);
        printf("Name                : %s\n", stddata[i].name);
        printf("Class               : %s\n", stddata[i].class);
        printf("Marks               : ");
        for (int j = 0; j < 5; j++) {
            printf("%d ", stddata[i].marks[j]);
        }
        printf("\n----------------------------------\n");
    }

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\11_strings> gcc f19.c -o f19; .\f19
Enter the Records of students :
------------------------------------
Record Number : 1
Enter the Roll no : 24
Enter the Name of Student : Yash
Enter the Class : 12
Enter Marks of Subject 1 : 90
Enter Marks of Subject 2 : 90
Enter Marks of Subject 3 : 90
Enter Marks of Subject 4 : 90
Enter Marks of Subject 5 : 90
--------------------------------------
Enter the Records of students :
------------------------------------
Record Number : 2
Enter the Roll no : 25
Enter the Name of Student : Aman
Enter the Class : 12
Enter Marks of Subject 1 : 90
Enter Marks of Subject 2 : 90
Enter Marks of Subject 3 : 90
Enter Marks of Subject 4 : 90
Enter Marks of Subject 5 : 90
--------------------------------------
Enter the Records of students :
------------------------------------
Record Number : 3
Enter the Roll no : 26
Enter the Name of Student : Ram
Enter the Class : 12
Enter Marks of Subject 1 : 60
Enter Marks of Subject 2 : 60
Enter Marks of Subject 3 : 60
Enter Marks of Subject 4 : 60
Enter Marks of Subject 5 : 60
--------------------------------------
Enter the Records of students :
------------------------------------
Record Number : 4
Enter the Roll no : 27
Enter the Name of Student : shyam
Enter the Class : 12
Enter Marks of Subject 1 : 8
Enter Marks of Subject 2 : 9
Enter Marks of Subject 3 : 8
Enter Marks of Subject 4 : 89
Enter Marks of Subject 5 : 89
--------------------------------------
Enter the Records of students :
------------------------------------
Record Number : 5
Enter the Roll no : 22
Enter the Name of Student : Ajay
Enter the Class : 12
Enter Marks of Subject 1 : 45
Enter Marks of Subject 2 : 45  
Enter Marks of Subject 3 : 45
Enter Marks of Subject 4 : 45
Enter Marks of Subject 5 : 45
--------------------------------------

=== Student Records ===

----------------------------------

Student Record number 1:

----------------------------------

Roll                : 24
Name                : Yash
Class               : 12
Marks               : 90 90 90 90 90
----------------------------------

Student Record number 2:

----------------------------------

Roll                : 25
Name                : Aman
Class               : 12
Marks               : 90 90 90 90 90
----------------------------------

Student Record number 3:

----------------------------------

Roll                : 26
Name                : Ram
Class               : 12
Marks               : 60 60 60 60 60
----------------------------------

Student Record number 4:

----------------------------------

Roll                : 27
Name                : shyam
Class               : 12
Marks               : 8 9 8 89 89
----------------------------------

Student Record number 5:

----------------------------------

Roll                : 22
Name                : Ajay
Class               : 12
Marks               : 45 45 45 45 45
----------------------------------

```
----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---