// 10 . Enter the string from user ,enter a number from user ,if the user enter 0 then you will print first character of string ,
//if the user enter 1 then you will print second character of string ,if user enter 2 then you will print third character of string ,
//if user enter 3 then you point fourth character of string and if out of string then you will print out of bound ?

#include <stdio.h>
#include <string.h>

int main(){
    char str[100];
    int n, len;

    printf("Enter the String : ");
    gets(str);

    len = strlen(str);

    printf("Enter the Number : ");
    scanf("%d", &n);

    if (n >= 0 && n < len)
        printf("Character at position %d is : %c", n, str[n]);
    else
        printf("Out of Bound");

    return 0;
}
