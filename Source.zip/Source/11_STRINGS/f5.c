// 5 . Enter a string from user and convert into toggle case ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){ 
        
        if (str[i]>=97 && str[i]<=122) 
        str[i]-=32;

        else if (str[i]>=65 && str[i]<=80)
        str[i]+=32;
    }

    printf("The String in Toggle case is :  %s" , str);

    return 0;
}