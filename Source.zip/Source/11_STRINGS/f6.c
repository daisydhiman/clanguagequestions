// 6. Enter a string from user and final length of the string ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20];
    printf("Enter the String :");
    gets(str);
    printf("The String Length is :  %d" , strlen(str));

    return 0;
}