// 17 . Enter the string from user and enter bound number and print character on that bound ?




#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int len,bound;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);
    printf("Enter the bound number :");
    scanf("%d",&bound);
    if (bound<=len && bound>0)
    printf("The Char that is bounded to %d is : %c",bound,str[bound-1]);
    else printf("Enter a valid bound Number");


    return 0;
}
