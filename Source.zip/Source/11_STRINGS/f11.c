// 11 . Enter the string from user and print each character in new line ?

#include <stdio.h>
#include <string.h>

int main() {
    char str[50] ; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);
    for (int i=0 ; i<len ; i++){
        printf("%c\n",str[i]);
    }

    return 0;
}
