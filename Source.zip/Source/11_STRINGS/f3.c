// 3 . Enter a string from user and convert into sentence case ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    if (str[0]>=97 && str[0]<=122) str[0]-=32 ; 

    for (int i=1 ; i<len ; i++){
        if (str[i]>=65 && str[i]<=80)
        str[i]= str[i]+32;
    }

    printf("The String in sentence case is :  %s" , str);

    return 0;
}