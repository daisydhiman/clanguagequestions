// 2 . Enter a string from user and convert into lowercase ?



#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){
        if (str[i]>=65 && str[i]<=80)
        str[i]= str[i]+32;
    }

    printf("Now the string is %s" , str);

    return 0;
}