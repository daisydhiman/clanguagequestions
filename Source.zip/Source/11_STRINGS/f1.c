// 1. Enter a string from user and convert in uppercase ?  

#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){
        if (str[i]>=97 && str[i]<=122)
        str[i]= str[i]-32;
    }

    printf("Now the string is %s" , str);

    return 0;
}