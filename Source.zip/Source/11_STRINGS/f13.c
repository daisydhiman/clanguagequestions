// 13 . Enter two string from user and print difference each character ?

#include <stdio.h>
#include <string.h>

int main(){
    char str1[100], str2[100];
    int len1,len2,minlen;

    printf("Enter First String : ");
    gets(str1);
    len1=strlen(str1);
    printf("Enter Second String : ");
    gets(str2);
    len2=strlen(str2);
    minlen= len1<len2? len1 : len2 ;

    for (int i =0 ; i<minlen ; i++ ){
        printf("\nThe ASCII difference of %c and %c is : %d",str1[i],str2[i],str1[i]-str2[i]);
    }


    return 0;
}