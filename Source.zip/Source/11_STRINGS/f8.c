// 8 . Enter a string from user and concatenate the string ?


#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[50];

    printf("Enter First String : ");
    gets(str1);

    printf("Enter Second String : ");
    gets(str2);

    strcat(str1, str2);

    printf("After Concatenation : %s", str1);

    return 0;
}
