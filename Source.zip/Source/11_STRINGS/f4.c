// 4 . Enter a string from user and convert into title case ?


#include <stdio.h>
#include <string.h>

int main(){
    char str[20]; int len,flag=1;
    printf("Enter the String :");
    gets(str);
    len=strlen(str);

    for (int i=0 ; i<len ; i++){

        if (str[i]==32) flag=1 ;  
        
        if (flag && (str[i]>=97 && str[i]<=122) ) {
        str[i]-=32 ;
        flag=0; } 

        else if (!flag && (str[i]>=65 && str[i]<=80))
        str[i]= str[i]+32;
    }

    printf("The String in Title case is :  %s" , str);

    return 0;
}