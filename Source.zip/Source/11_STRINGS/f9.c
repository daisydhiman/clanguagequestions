// 9 . Enter a string from user and copy that string into another string ?

#include <stdio.h>
#include <string.h>

int main() {
    char str[100], cpy[100];

    printf("Enter Thr String To be COPIED : ");
    gets(str);

    strcpy(cpy, str);

    printf("Copy of String 1 is : %s", cpy);

    return 0;
}
