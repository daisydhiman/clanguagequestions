// 18 . String palindrome example (using reverse) ?


#include <stdio.h>
#include <string.h>

int main() {
    char str[100], rev[100];
    int len, i, j, isPalindrome = 1;
    printf("Enter the string : ");
    gets(str);
    len = strlen(str);


    for (i = 0, j = len - 1; i < len; i++, j--) {
        rev[i] = str[j];
    }
    rev[len] = '\0'; 

    for (i = 0; i < len; i++) {
        if (str[i] != rev[i]) {
            isPalindrome = 0;
            break;
        }
    }

    if (isPalindrome)
        printf("%s is a Palindrome", str);
    else
        printf("%s is Not a palindrome", str);

    return 0;
}
