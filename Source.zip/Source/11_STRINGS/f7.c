// 7 . Enter a string from user and compare those string ?

#include <stdio.h>
#include <string.h>

int main() {
    char str1[50], str2[50];

    printf("Enter First String : ");
    gets(str1);
    printf("Enter Second String : ");
    gets(str2);

    if (strcmp(str1, str2) == 0)
        printf("Both strings are SAME");
    else
        printf("Strings are DIFFERENT");

    return 0;
}
