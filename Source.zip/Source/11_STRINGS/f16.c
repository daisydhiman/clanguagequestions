// 16 . Enter the string from user and count all vowels ?


#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int count=0,len;
    printf("Enter The String : ");
    gets(str);
    len=strlen(str);

    for (int i=0; i <len ; i++){

        switch (str[i]){
            case 'a':
            count++;
            break;
            case 'e':
            count++;
            break;
            case 'i':
            count++;
            break;
            case 'o':
            count++;
            break;
            case 'u':
            count++;
            break;
            case 'A':
            count++;
            break;
            case 'E':
            count++;
            break;
            case 'I':
            count++;
            break;
            case 'O':
            count++;
            break;
            case 'U':
            count++;
            break;
        }
        
    }

    printf ("The number of vowels in %s is %d",str,count);

    return 0;
}
