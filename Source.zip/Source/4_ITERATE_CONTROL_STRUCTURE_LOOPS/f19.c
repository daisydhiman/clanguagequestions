// 19. Enter password from user maximum 20 digits / character press enter key if you want to exit ?


#include <stdio.h>
#include <conio.h>

int main() {
    char ch;
    int i = 0;

    printf("Enter the password (press Enter to exit):");

    while (1) {
        ch = getche();     
        if (ch == 13)        
            break;
        i++;
        if (i >= 20)
            break;
    }

    return 0;
}
