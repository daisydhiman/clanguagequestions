// 3 . Enter a number from the user and check it is a prime number or not ?
#include<stdio.h>
#include<conio.h>

int main(){
    int n,count=0,i;
    printf("enter the number :");
    scanf("%d",&n);

    if(n<=1)
    printf("%d is not a prime number",n);
else
for(i=1;i<=n;i++)
{
    if(n%i==0)
    count++;

}
if(count>2)
printf("%d is not a prime number",n);
//a prime no. never divided by 2 numbwrs.
else
printf("%d is a prime number.",n);
return 0;
}
    
