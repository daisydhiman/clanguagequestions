// 15 .  Enter a number from user and print first digit of number ?
#include <stdio.h>

int main() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);


    if (number < 0) {
        number = -number; 
    } 
    while (number >= 10) {
        number /= 10;
    }

    printf("The first digit is: %d\n", number);

    return 0;
}