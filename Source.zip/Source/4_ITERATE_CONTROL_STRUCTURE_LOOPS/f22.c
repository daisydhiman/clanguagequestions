// 22 . Enter a character from user and that character should be alphabet ?
#include <stdio.h>

int main() {
    char ch;
    printf("Enter the char : ");
    scanf("%c", &ch);
    if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122))
        printf("alphabet");
    else
        printf("Not alphabet");
    return 0;
}
