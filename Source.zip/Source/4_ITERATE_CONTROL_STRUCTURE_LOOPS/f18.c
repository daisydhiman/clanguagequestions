// 18 . Enter two numbers from user and print range from first number to second number ?
#include<stdio.h>

int main(){
    int x,y,range=1,i;
    printf("enter the first number :");
    scanf("%d",&x);

    printf("enter the second number :");
    scanf("%d",&y);
 for(i=x;i<=y;i++)
 {
    range++;
 }
 printf("the range from %d to %d is %d",x,y,range);
 return 0;
}