//7 . Enter a number from the user and print the series from 1 to that number ?
#include<stdio.h>
#include<conio.h>

int main(){
    int x,i;
    printf("enter the number :");
    scanf("%d",&x);
  
    for(i=1;i<=x;i++)
    {
        printf("%d\n",i);
    }
    return 0;
}