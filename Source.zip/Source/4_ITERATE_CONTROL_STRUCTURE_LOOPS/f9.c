// 9 .Write a program print all the odd number between 1 to 100 ?
#include<stdio.h>
#include<conio.h>

int main(){
    int i;
    for(i=1;i<=100;i=+2)
    {
        printf("%d\n",i);
    }
    return 0;
}