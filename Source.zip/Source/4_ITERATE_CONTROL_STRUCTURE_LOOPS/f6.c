//6 . Write a program to print a series 1 to 1 lakh ?

#include<stdio.h>
#include<conio.h>

int main(){
    int i;
    for(i=1;i<=100000;i++)
    printf("%d\n",i);

    return 0;
}