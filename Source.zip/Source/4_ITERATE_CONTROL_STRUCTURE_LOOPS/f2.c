// / 2. Enter a number from the user and check that the number is divisible by any prime number or not ?


#include <stdio.h>

int main() {
    int n,i,j,flag=0,prime;
    printf("Enter a number:");
    scanf("%d",&n);
    for(i=2 ;i<=n/2 ;i++) {
        prime=1;
        for(j=2 ; j<=i/2 ; j++) {
            if(i%j==0) {
                prime=0;
                break;
            }
        }
        if( prime==1 && n%i==0 ) {
            flag=1;
            break;
        }
    }
    if( flag==1 )
        printf("Number is divisible by a prime number");
    else
        printf("Number is not divisible by any prime number");
    return 0;
}
