// 16. Enter a number from user and print total from 0 to that number ?
#include<stdio.h>

int main(){
    int x,sum=0,i;
    printf("enter the number :");
    scanf("%d",&x);

    for(i=0;i<=x;i++)
    {
        sum=sum+i;
        
    }
    printf("%d",sum);
    return 0;
}