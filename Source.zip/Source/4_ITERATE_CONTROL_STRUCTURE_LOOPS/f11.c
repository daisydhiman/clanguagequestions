// 11 . Enter the number from user and reverse the number?
#include<stdio.h>
#include<conio.h>

int main(){
    int x,remainder;

    printf("enter the number :");
    scanf("%d",&x);
     while(x!=0)
     {
        remainder=x%10;
      printf("%d\n",remainder);
      x=x/10;
     }
     return 0;
}