// 14. Enter two numbers from users, one is base and second is power. Write the result ?
#include<stdio.h>

int main(){
    int x,y,result=1;
    printf("enter the base number :");
    scanf("%d",&x);

    printf("enter the power number :");
    scanf("%d",&y);
    if(y==0)
    printf("the value is 1.");
    else
    while(y>0)
    {
        result = result * x;
        y--;
    }
    printf("Result is  %d",result);
 
    return 0;
}