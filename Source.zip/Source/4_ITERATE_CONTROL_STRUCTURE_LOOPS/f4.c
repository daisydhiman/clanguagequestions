//4. Enter a number from the user and print all digit of the number in separate line 


#include <stdio.h>

int main() {
    int n, r, rev = 0;
    printf("Enter the number : ");
    scanf("%d", &n);
    while (n > 0) {
        r = n % 10;
        rev = rev *10 + r;
        n = n/10;
    }
    while (rev > 0) {
        r = rev %10;
        printf("%d\n", r);
        rev = rev/10;
    }
    return 0;
}
