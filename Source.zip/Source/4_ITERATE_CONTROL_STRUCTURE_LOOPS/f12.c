// 12 . Enter a number from the user if the user enter 1 then you will perform addition operation by entering 2 number from user add it and display answer.
//  if user enter 2 then subtract or if user enter 3 then multiply or if user enter 4 then divide or if user enter 5 then modulo or if any other number then print invalid .
// if user want to quit the program then user will enter Q. ?
#include<stdio.h>
#include<conio.h>

int main(){
    int x;
    int num1,num2;
    printf("enter the to perform operation :");
    scanf("%d",&x);
    printf("enter first numbwrs :");
    scanf("%d",&num1);

    printf("enter second numbwrs :");
    scanf("%d",&num2);

    switch(x)
    {
        case 1: printf("the addition of the number is %d",num1+num2);
        break;
        case 2:printf("the subtraction of the number is %d",num1-num2);
        break;
    case 3:printf("the multiplication of the number is %d",num1*num2);
        break;
        case 4:printf("the division of the number is %d",num1/num2);
        break;

    }
    return 0;
}