//10 . Write a program print the table of 4 in the format given as below (till 20)? 4*1=4 and so on
#include<stdio.h>


int main(){
    int x=4,i=1,table;
    for(i=1;i<=10;i++)
    {
        table=x*i;
        printf("%d\n",table);
    }
    return 0;
}