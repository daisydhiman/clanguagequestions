//13 . Enter the number from user and check its palindrome or not?

#include<stdio.h>

int main(){
    int n,c,s=0,r;
    printf("enter the number :");
    scanf("%d",&n);

    c=n;
    while(n>0){
        r=n%10;
        s=r+(s*10);
        n/=10;
    }

    if(c==s)
    printf("yes the number is palindrom number ");
    else
    printf("the number is not the palindrom number ");

return 0;



}