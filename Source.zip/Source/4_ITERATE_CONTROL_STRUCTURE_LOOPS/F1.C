// 1. Enter a number from the user and find out the binary of that number ?

#include <stdio.h>

int main() {
    int n, b[32], i = 0;
    printf("Enter the number : "); 
    scanf("%d", &n);
    while (n > 0) {
        b[i] = n % 2;
        n = n / 2;
        i++;
    }
    for (i = i - 1; i >= 0; i--)
        printf("%d", b[i]);
    return 0;
}
