// 20 . Write a program to print the counting 1 to 100 with one second delay ?
#include<stdio.h>
#include<dos.h>

int main()
{
    int i;
    for(i=1;i<=100;)
    {
        i++;
    }
    printf("%d\n",i);
    delay(1000);
    return 0;
}