# LOOPs
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
// 1. Enter a number from the user and find out the binary of that number ?

#include <stdio.h>

int main() {
    int n, b[32], i = 0;
    printf("Enter the number : "); 
    scanf("%d", &n);
    while (n > 0) {
        b[i] = n % 2;
        n = n / 2;
        i++;
    }
    for (i = i - 1; i >= 0; i--)
        printf("%d", b[i]);
    return 0;
}


OUTPUT 

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f1.c -o f1; .\f1
Enter the number : 344
101011000

```

---

## 2. 
```c
// / 2. Enter a number from the user and check that the number is divisible by any prime number or not ?


#include <stdio.h>

int main() {
    int n,i,j,flag=0,prime;
    printf("Enter a number:");
    scanf("%d",&n);
    for(i=2 ;i<=n/2 ;i++) {
        prime=1;
        for(j=2 ; j<=i/2 ; j++) {
            if(i%j==0) {
                prime=0;
                break;
            }
        }
        if( prime==1 && n%i==0 ) {
            flag=1;
            break;
        }
    }
    if( flag==1 )
        printf("Number is divisible by a prime number");
    else
        printf("Number is not divisible by any prime number");
    return 0;
}


OUTPUT

```
---

## 3.


```c
// 3 . Enter a number from the user and check it is a prime number or not ?
#include<stdio.h>
#include<conio.h>

int main(){
    int n,count=0,i;
    printf("enter the number :");
    scanf("%d",&n);

    if(n<=1)
    printf("%d is not a prime number",n);
else
for(i=1;i<=n;i++)
{
    if(n%i==0)
    count++;

}
if(count>2)
printf("%d is not a prime number",n);
//a prime no. never divided by 2 numbwrs.
else
printf("%d is a prime number.",n);
return 0;
}
    



OUTPUT 

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f3.c -o f3; .\f3
enter the number :43
43 is a prime number.

```
---

## 4. 
```c
// //4. Enter a number from the user and print all digit of the number in separate line 


#include <stdio.h>

int main() {
    int n, r, rev = 0;
    printf("Enter the number : ");
    scanf("%d", &n);
    while (n > 0) {
        r = n % 10;
        rev = rev *10 + r;
        n = n/10;
    }
    while (rev > 0) {
        r = rev %10;
        printf("%d\n", r);
        rev = rev/10;
    }
    return 0;
}


OUTPUT 

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f4.c -o f4; .\f4
Enter the number : 232323
2
3
2
3
2
3

```

---

## 5 .

```c
//5. Write a program to print your name 1 lakh times ?
#include<stdio.h>


int main()
{
    int i;
    char name[20];
    printf("enetr your name :");
  gets(name);

    for(i=1;i<=100000;i++)
    {
      printf("%s\n",name);
    }
    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f5.c -o f5; .\f5
enetr your name :daisy
daisy
....
daisy

```

---
## 6. 

```c
//6 . Write a program to print a series 1 to 1 lakh ?

#include<stdio.h>
#include<conio.h>

int main(){
    int i;
    for(i=1;i<=100000;i++)
    printf("%d\n",i);

    return 0;
}

OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f6.c -o f6; .\f6
1
2
....

```

----
## 7. 

```c
//7 . Enter a number from the user and print the series from 1 to that number ?
#include<stdio.h>
#include<conio.h>

int main(){
    int x,i;
    printf("enter the number :");
    scanf("%d",&x);
  
    for(i=1;i<=x;i++)
    {
        printf("%d\n",i);
    }
    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f7.c -o f7; .\f7
enter the number :6 
1
2
3
4
5
6


```

---

## 8. 

```c
//8 .Enter a number from the user and print that number 100 time ?
#include<stdio.h>
#include<conio.h>

int main()
{
    int x,i;
    printf("enter the number :");
    scanf("%d",&x);

    for(i=1;i<=100;i++)
    {
        printf("%d\n",x);
    }
    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f8.c -o f8; .\f8
enter the number :3
3
3
3
3
...

```

---

## 9. 

```c
/// 9 .Write a program print all the odd number between 1 to 100 ?
#include<stdio.h>
#include<conio.h>

int main(){
    int i;
    for(i=1;i<=100;i=+2)
    {
        printf("%d\n",i);
    }
    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f9.c -o f9; .\f9
1
3
....

```

----

## 10. 
```c
//10 . Write a program print the table of 4 in the format given as below (till 20)? 4*1=4 and so on
#include<stdio.h>


int main(){
    int x=4,i=1,table;
    for(i=1;i<=10;i++)
    {
        table=x*i;
        printf("%d\n",table);
    }
    return 0;
}



OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f10.c -o f10; .\f10
4
8
12
16
20
24
28
32
36
40
```

----
## 11.

```c
// 11 . Enter the number from user and reverse the number?
#include<stdio.h>
#include<conio.h>

int main(){
    int x,remainder;

    printf("enter the number :");
    scanf("%d",&x);
     while(x!=0)
     {
        remainder=x%10;
      printf("%d\n",remainder);
      x=x/10;
     }
     return 0;
}



OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f11.c -o f11; .\f11
enter the number :34334
4
3
3
4
3

```
----

## 12. 

```c
// 12 . Enter a number from the user if the user enter 1 then you will perform addition operation by entering 2 number from user add it and display answer.
//  if user enter 2 then subtract or if user enter 3 then multiply or if user enter 4 then divide or if user enter 5 then modulo or if any other number then print invalid .
// if user want to quit the program then user will enter Q. ?
#include<stdio.h>
#include<conio.h>

int main(){
    int x;
    int num1,num2;
    printf("enter the to perform operation :");
    scanf("%d",&x);
    printf("enter first numbwrs :");
    scanf("%d",&num1);

    printf("enter second numbwrs :");
    scanf("%d",&num2);

    switch(x)
    {
        case 1: printf("the addition of the number is %d",num1+num2);
        break;
        case 2:printf("the subtraction of the number is %d",num1-num2);
        break;
    case 3:printf("the multiplication of the number is %d",num1*num2);
        break;
        case 4:printf("the division of the number is %d",num1/num2);
        break;

    }
    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f12.c -o f12; .\f12
enter the to perform operation :3
enter first numbwrs :232
enter second numbwrs :33
the multiplication of the number is 7656


```

----
## 13.

```c
//13 . Enter the number from user and check its palindrome or not?

#include<stdio.h>

int main(){
    int n,c,s=0,r;
    printf("enter the number :");
    scanf("%d",&n);

    c=n;
    while(n>0){
        r=n%10;
        s=r+(s*10);
        n/=10;
    }

    if(c==s)
    printf("yes the number is palindrom number ");
    else
    printf("the number is not the palindrom number ");

return 0;



}


enter the number :12342
the number is not the palindrom number 
PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f13.c -o f13; .\f13
enter the number :121
yes the number is palindrom number 

```

----

## 14. 
```c
// 14. Enter two numbers from users, one is base and second is power. Write the result ?
#include<stdio.h>

int main(){
    int x,y,result=1;
    printf("enter the base number :");
    scanf("%d",&x);

    printf("enter the power number :");
    scanf("%d",&y);
    if(y==0)
    printf("the value is 1.");
    else
    while(y>0)
    {
        result = result * x;
        y--;
    }
    printf("Result is  %d",result);
 
    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f14.c -o f14; .\f14
enter the base number :23
enter the power number :
3
Result is  12167

```

---
## 15 .

```c
/// 15 .  Enter a number from user and print first digit of number ?
#include <stdio.h>

int main() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);


    if (number < 0) {
        number = -number; 
    } 
    while (number >= 10) {
        number /= 10;
    }

    printf("The first digit is: %d\n", number);

    return 0;
}

OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f15.c -o f15; .\f15
Enter a number: 2345
The first digit is: 2

```
---

## 16. 
```c
// 16. Enter a number from user and print total from 0 to that number ?
#include<stdio.h>

int main(){
    int x,sum=0,i;
    printf("enter the number :");
    scanf("%d",&x);

    for(i=0;i<=x;i++)
    {
        sum=sum+i;
        
    }
    printf("%d",sum);
    return 0;
}



OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f16.c -o f16; .\f16
enter the number :234
27495

```

---

## 17. 
```c

// 17 .Enter a number from user and find out factorial of that number ?

#include <stdio.h>

int main() {
    int num;
    int factorial = 1; 


    printf("Enter the number : ");
    scanf("%d", &num);


    if (num < 0) {
        printf("Factorial is not defined for negative numbers");
    } else {

        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }
        printf("Factorial of %d is :  %d", num, factorial);
    }

    return 0;
}


OUTPUT 

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f17.c -o f17; .\f17
Enter the number : 4
Factorial of 4 is :  24


```

----

## 18 . 

```c
/// 18 . Enter two numbers from user and print range from first number to second number ?
#include<stdio.h>

int main(){
    int x,y,range=1,i;
    printf("enter the first number :");
    scanf("%d",&x);

    printf("enter the second number :");
    scanf("%d",&y);
 for(i=x;i<=y;i++)
 {
    range++;
 }
 printf("the range from %d to %d is %d",x,y,range);
 return 0;
}


OUTPUT 


PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f18.c -o f18; .\f18
enter the first number :34
enter the second number :56
the range from 34 to 56 is 24

```

---

## 19.

```c

// 19. Enter password from user maximum 20 digits / character press enter key if you want to exit ?


#include <stdio.h>
#include <conio.h>

int main() {
    char ch;
    int i = 0;

    printf("Enter the password (press Enter to exit):");

    while (1) {
        ch = getche();     
        if (ch == 13)        
            break;
        i++;
        if (i >= 20)
            break;
    }

    return 0;
}


OUTPUT

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f19.c -o f19; .\f19
Enter the password (press Enter to exit):password

```

---


## 20 . 


```c

// 20 . Write a program to print the counting 1 to 100 with one second delay ?
#include<stdio.h>
#include<dos.h>

int main()
{
    int i;
    for(i=1;i<=100;)
    {
        i++;
    }
    printf("%d\n",i);
    delay(1000);
    return 0;
}


OUTPUTS

...


```

---


## 21.

```c
// 21 . Write a program to find out the Fibonacci series/ 1 to 100 (like 0 1 1 2 3 5 8 13………..) ?
#include<stdio.h>


 int main()
 {int x,a=0,b=1,c,i; 
    printf("enter the numebr of term :");
     scanf("%d",&x);
     for(i=1;i<=x;i++)
     {
        printf("%d  ",a);
        c=a+b;
        a=b;
        b=c;
     } 
     return 0;



}




OUTPUTS

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f21.c -o f21; .\f21
enter the numebr of term :5
0  1  1  2  3 

```

---

## 22 

```c

// 22 . Enter a character from user and that character should be alphabet ?
#include <stdio.h>

int main() {
    char ch;
    printf("Enter the char : ");
    scanf("%c", &ch);
    if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122))
        printf("alphabet");
    else
        printf("Not alphabet");
    return 0;
}


OUTPUTS 

PS E:\dx\Coding\C_4205_BCA\source\4_iterate_control_structure_loops> gcc f22.c -o f22; .\f22
Enter the char : 3
Not alphabet

```
---





----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---