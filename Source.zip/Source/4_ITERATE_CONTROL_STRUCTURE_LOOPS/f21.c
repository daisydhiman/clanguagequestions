// 21 . Write a program to find out the Fibonacci series/ 1 to 100 (like 0 1 1 2 3 5 8 13………..) ?
#include<stdio.h>


 int main()
 {int x,a=0,b=1,c,i; 
    printf("enter the numebr of term :");
     scanf("%d",&x);
     for(i=1;i<=x;i++)
     {
        printf("%d  ",a);
        c=a+b;
        a=b;
        b=c;
     } 
     return 0;



}

