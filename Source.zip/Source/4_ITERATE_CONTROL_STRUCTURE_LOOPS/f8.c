//8 .Enter a number from the user and print that number 100 time ?
#include<stdio.h>
#include<conio.h>

int main()
{
    int x,i;
    printf("enter the number :");
    scanf("%d",&x);

    for(i=1;i<=100;i++)
    {
        printf("%d\n",x);
    }
    return 0;
}