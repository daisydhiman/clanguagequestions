//4. Write a program to print your name 1 lakh times ?
#include<stdio.h>


int main()
{
    int i;
    char name[20];
    printf("enetr your name :");
  gets(name);

    for(i=1;i<=100000;i++)
    {
      printf("%s\n",name);
    }
    return 0;
}