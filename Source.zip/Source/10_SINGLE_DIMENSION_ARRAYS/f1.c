/// 1 . Enter an array from user and display all the value ?


#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    for (int i =0 ; i<5 ; i++){
        printf("\nthe number %d in the array  : %d",i+1,arr[i]);
    }



}