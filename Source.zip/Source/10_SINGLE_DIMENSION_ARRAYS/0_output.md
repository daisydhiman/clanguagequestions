# SINGLE DIMENSION ARRAYSS
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
/// 1 . Enter an array from user and display all the value ?


#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    for (int i =0 ; i<5 ; i++){
        printf("\nthe number %d in the array  : %d",i+1,arr[i]);
    }



}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f1.c -o f1; .\f1
Enter the number : 32
Enter the number : 2
Enter the number : 2
Enter the number : 21
Enter the number : 23

the number 1 in the array  : 32
the number 2 in the array  : 2
the number 3 in the array  : 2
the number 4 in the array  : 21
the number 5 in the array  : 23

```

---

## 2. 
```c
// 2 . Enter an array from user and print the array in reverse order ?



#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("The array in reverse order is : \n");
    for (int i=4 ; i>=0 ; i--){
        printf("%d\n",arr[i]);
    }



}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f2.c -o f2; .\f2
Enter the number : 2
Enter the number : 32
Enter the number : 323
Enter the number : 3
Enter the number : 5
The array in reverse order is : 
5
3
323
32
2

```

---

## 3.
```c
/// 3 . Enter an array from user and copy the array into second array ?


#include <stdio.h>

int main(){
    int arr[5] ,cpy[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }

    for( int i=0  ; i<5 ; i++){
        cpy[i]=arr[i];
    }

        printf("Arter COPING ");
        for (int i =0 ; i<5 ; i++){
            printf("\nthe number %d in the Copied array  : %d",i+1,arr[i]);
        }
    
    


}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f3.c -o f3; .\f3
Enter the number : 2
Enter the number : 23
Enter the number : 33
Enter the number : 67
Enter the number : 7
Arter COPING 
the number 1 in the Copied array  : 2
the number 2 in the Copied array  : 23
the number 3 in the Copied array  : 33
the number 4 in the Copied array  : 67
the number 5 in the Copied array  : 7

```
---

## 4. 
```c
// 4. Enter an array from user and copy it into another array in reverse order ?

#include <stdio.h>

int main() {
    int arr[5], cpy[5];

    for (int i = 0; i < 5; i++) {
        printf("Enter the number : ");
        scanf("%d", &arr[i]);
    }

    for (int i = 0; i < 5; i++) {
        cpy[i] = arr[4 - i];
    }

    printf("After COPYING in reverse Order\n");
    for (int i = 0; i < 5; i++) {
        printf("The number %d in the Copied array : %d\n", i + 1, cpy[i]);
    }

    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f4.c -o f4; .\f4
Enter the number : 23
Enter the number : 23
Enter the number : 23
Enter the number : 34
Enter the number : 
7
After COPYING in reverse Order
The number 1 in the Copied array : 7
The number 2 in the Copied array : 34
The number 3 in the Copied array : 23
The number 4 in the Copied array : 23
The number 5 in the Copied array : 23

```

---

## 5 .

```c
// 5 . Enter an array from user and print the number which is even ?


#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("Only Even numbers in array  : \n");
    for (int i=0 ; i<5 ; i++){
        if (arr[i]%2==0)
        printf("%d\n",arr[i]);
    }



}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f5.c -o f5; .\f5
Enter the number : 232
Enter the number : 33
Enter the number : 5
Enter the number : 6678
Enter the number : 20
Only Even numbers in array  : 
232
6678
20

```

---
## 6. 

```c
// 6 . Enter an array from user and print the number which is positive ?

#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("Only Positive numbers in array  : \n");
    for (int i=0 ; i<5 ; i++){
        if (arr[i]>0)
        printf("%d\n",arr[i]);
    }



}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f6.c -o f6; .\f6
Enter the number : 23
Enter the number : -44
Enter the number : 34
Enter the number : -7
Enter the number : 50
Only Positive numbers in array  : 
23
34
50

```

----
## 7. 

```c
// 7 . Enter an array from user and square all the values of array ?


#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("Square of numbers in array  : \n");
    for (int i=0 ; i<5 ; i++){
        printf("%d\n",arr[i]*arr[i]);
    }



}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f7.c -o f7; .\f7
Enter the number : 34
Enter the number : 346
Enter the number : 7
Enter the number : 65
Enter the number : 2
Square of numbers in array  : 
1156
119716
49
4225
4


```

---

## 8. 

```c
// 8  . Enter 5 values of array from user and print odd number of array ?


#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("Only ODD numbers in array  : \n");
    for (int i=0 ; i<5 ; i++){
        if (!(arr[i]%2==0))
        printf("%d\n",arr[i]);
    }



}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f8.c -o f8; .\f8 
Enter the number : 67
Enter the number : 2
Enter the number : 34
Enter the number : 3
Enter the number : 68
Only ODD numbers in array  : 
67
3

```

---

## 9. 

```c
// 9  . Enter 5 values of array from user and add all values ?

#include <stdio.h>

int main(){
    int arr[5],sum=0;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
  
    for (int i=0 ; i<5 ; i++){
        sum+=arr[i];
    }
    printf("SUM of numbers in array  : %d\n", sum);


}

OUTPUT
PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f9.c -o f9; .\f9
Enter the number : 23
Enter the number : 4544
Enter the number : 67
Enter the number : 887
Enter the number : 55
SUM of numbers in array  : 5576

```

----

## 10. 
```c
// 1 0 . Enter 5 values of array from user, 
// enter a value from user and search this value in array,
//  if value is found then print “found” or not then print “not found”?


#include <stdio.h>

int main(){
    int arr[5],a,found=0;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }

    printf("Enter the Number to check : ");
    scanf("%d",&a);
    
  
    for (int i=0 ; i<5 ; i++){
        if (arr[i]==a)
        found=1;
    }
   
    found ? printf("Found") : printf("NoT Found") ;


}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f10.c -o f10; .\f10
Enter the number : 343
Enter the number : 44
Enter the number : 67
Enter the number : 89
Enter the number : 01
Enter the Number to check : 4
NoT Found

```

----
## 11.

```c
// 11. Enter five values of array and sort in ascending order ?

#include <stdio.h>

int main(){
    int arr[5], temp;

    for(int i=0; i<5; i++){
        printf("Enter number %d : ", i+1);
        scanf("%d", &arr[i]);
    }


    for(int i=0; i<5-1; i++){
        for(int j=i+1; j<5; j++){
            if(arr[i] > arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }

    printf("\nAscending order:\n");
    for(int i=0; i<5; i++){
        printf("%d ", arr[i]);
    }

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f11.c -o f11; .\f11
Enter number 1 : 34
Enter number 2 : 5
Enter number 3 : 55
Enter number 4 : 568
Enter number 5 : 89

Ascending order:
5 34 55 89 568

```
----

## 12. 

```c
// 12 .  Find maximum values of array ?


#include <stdio.h>

int main(){
    int arr[5],max;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }

    max = arr[0];

    for(int i=1; i<5; i++){
        if(arr[i] > max)
            max = arr[i];
    }

    printf("The Maximum Value is : %d", max);
    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f12.c -o f12; .\f12
Enter the number : 232
Enter the number : 345
Enter the number : 78
Enter the number : 0
Enter the number : 45
The Maximum Value is : 345


```

----
## 13.

```c
// 13. Find minimum value of array ?

#include <stdio.h>

int main(){
    int arr[5], min;

    for(int i=0; i<5; i++){
        printf("Enter the number : ");
        scanf("%d", &arr[i]);
    }

    min = arr[0];

    for(int i=1; i<5; i++){
        if(arr[i] < min)
            min = arr[i];
    }

    printf("The Minimum Value is : %d", min);

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\10_single_dimension_arrays> gcc f13.c -o f13; .\f13
Enter the number : 23
Enter the number : 55
Enter the number : 6
Enter the number : 9
Enter the number : 1
The Minimum Value is : 1

```

----


----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---