// 4. Enter an array from user and copy it into another array in reverse order ?

#include <stdio.h>

int main() {
    int arr[5], cpy[5];

    for (int i = 0; i < 5; i++) {
        printf("Enter the number : ");
        scanf("%d", &arr[i]);
    }

    for (int i = 0; i < 5; i++) {
        cpy[i] = arr[4 - i];
    }

    printf("After COPYING in reverse Order\n");
    for (int i = 0; i < 5; i++) {
        printf("The number %d in the Copied array : %d\n", i + 1, cpy[i]);
    }

    return 0;
}
