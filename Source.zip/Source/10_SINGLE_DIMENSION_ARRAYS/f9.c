// 9  . Enter 5 values of array from user and add all values ?

#include <stdio.h>

int main(){
    int arr[5],sum=0;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
  
    for (int i=0 ; i<5 ; i++){
        sum+=arr[i];
    }
    printf("SUM of numbers in array  : %d\n", sum);


}