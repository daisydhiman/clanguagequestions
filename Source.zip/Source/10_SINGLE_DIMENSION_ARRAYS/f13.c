// 13. Find minimum value of array ?

#include <stdio.h>

int main(){
    int arr[5], min;

    for(int i=0; i<5; i++){
        printf("Enter the number : ");
        scanf("%d", &arr[i]);
    }

    min = arr[0];

    for(int i=1; i<5; i++){
        if(arr[i] < min)
            min = arr[i];
    }

    printf("The Minimum Value is : %d", min);

    return 0;
}
