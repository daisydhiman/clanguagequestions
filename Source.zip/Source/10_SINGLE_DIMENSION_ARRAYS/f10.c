// 1 0 . Enter 5 values of array from user, 
// enter a value from user and search this value in array,
//  if value is found then print “found” or not then print “not found”?


#include <stdio.h>

int main(){
    int arr[5],a,found=0;
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }

    printf("Enter the Number to check : ");
    scanf("%d",&a);
    
  
    for (int i=0 ; i<5 ; i++){
        if (arr[i]==a)
        found=1;
    }
   
    found ? printf("Found") : printf("NoT Found") ;


}