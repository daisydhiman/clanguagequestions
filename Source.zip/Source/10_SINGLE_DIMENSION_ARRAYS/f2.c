// 2 . Enter an array from user and print the array in reverse order ?



#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("The array in reverse order is : \n");
    for (int i=4 ; i>=0 ; i--){
        printf("%d\n",arr[i]);
    }



}