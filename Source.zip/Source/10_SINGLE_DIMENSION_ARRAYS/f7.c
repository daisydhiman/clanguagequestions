// 7 . Enter an array from user and square all the values of array ?


#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("Square of numbers in array  : \n");
    for (int i=0 ; i<5 ; i++){
        printf("%d\n",arr[i]*arr[i]);
    }



}