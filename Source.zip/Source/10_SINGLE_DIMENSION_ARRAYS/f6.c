// 6 . Enter an array from user and print the number which is positive ?

#include <stdio.h>

int main(){
    int arr[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }
    
    printf("Only Positive numbers in array  : \n");
    for (int i=0 ; i<5 ; i++){
        if (arr[i]>0)
        printf("%d\n",arr[i]);
    }



}