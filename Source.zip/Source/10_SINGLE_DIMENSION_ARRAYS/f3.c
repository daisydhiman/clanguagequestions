/// 3 . Enter an array from user and copy the array into second array ?


#include <stdio.h>

int main(){
    int arr[5] ,cpy[5];
    for (int i =0 ; i<5 ; i++){
        printf("Enter the number : ");
        scanf("%d",&arr[i]);
    }

    for( int i=0  ; i<5 ; i++){
        cpy[i]=arr[i];
    }

        printf("Arter COPING ");
        for (int i =0 ; i<5 ; i++){
            printf("\nthe number %d in the Copied array  : %d",i+1,arr[i]);
        }
    
    


}