#include <stdio.h>
#include <string.h>

// struct datatem returndata(char *name,char *roll,char *age){
// }

int verifyname(char * name){
    int flag=1;
    for (int i=0 ; name[i]!='\0' ; i++){
        if (!((name[i]>=65 && name[i]<=90) || (name[i]>=97 && name[i]<=122) || name[i]==32))
        return 0;
    }
    for (int i=0 ; name[i]!='\0' ; i++){
        if ()
    }

    return 1;
}

int verifyroll(char * roll){

    if (strlen(roll)!=7) return 0;

    for (int i=0 ; roll[i]!='\0' ; i++){

        if (i == 4) {             
            if (roll[i] != 47) return 0;
        } else {                 
            if (roll[i] < 48 || roll[i] > 57) return 0;
        }
    }
    return 1;
}

int verifyage(char * age){
    for (int i=0 ; age[i]!='\0' ; i++){
        if (!(age[i]>=48 && age[i]<=57 && strlen(age)<3))
        return 0;
    }
    return 1;
}



int main(){
    int size=5;
    char namev[51],rollv[8],agev[3];

    struct datatem{
        char name[51];
        char roll[8];
        char age[3];
    };

    struct datatem stddata[size];
    for ( int i=0 ; i < size ; i++){

        printf("Enter the Records of students :\n");
        printf("------------------------------------\n");

        printf("Record Number : %d\n",i+1);

        name:

        printf("Enter the Name of Student (Format Title Case) :");
        gets(namev);
        fflush(stdin);

        if (verifyname(namev)==0){
        printf("\n Enter name in valid format ! \n");
        goto name; 
        }
        strcpy(stddata[i].name, namev);


        roll:


        printf("Enter the Roll no (format RRRR/YY) :");
        gets(rollv);
        fflush(stdin);

        if (verifyroll(rollv)==0){
        printf("\nEnter in a Valid Format :\n");
        goto roll;
        }
        strcpy(stddata[i].roll, rollv);


        age:


        printf("Enter the age in Years (format YY) : ");
        gets(agev);
        fflush(stdin);

        if (verifyage(agev)==0){
        printf("\nEnter age in valid format !\n");
        goto age;
    }
    strcpy(stddata[i].age, agev);

        printf("--------------------------------------\n");


    }

    printf("\n=== Student Records ===\n");
    printf("\n----------------------------------\n");
    for (int i=0; i<size; i++){
        printf("\nStudent Record number %d:\n", i+1);
        printf("\n----------------------------------\n\n");
        printf("Name                : %s\n", stddata[i].name);
        printf("Roll                : %s\n", stddata[i].roll);
        printf("Age                 : %s\n", stddata[i].age);
        printf("\n----------------------------------\n");
    }

    return 0; 
}