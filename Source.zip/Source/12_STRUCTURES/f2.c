// 2. Create structure of employee which there is emp.ID, name, designation of 50 employees from user and print only name of the employee ?


#include <stdio.h>
#include <string.h>

// ----------------------------------------------

int verifyempid(char * empid){

    if (strlen(empid)!=4) return 0;

    for (int i=0 ; empid[i]!='\0' ; i++){
        if (empid[i] < 48 || empid[i] > 57) return 0;
    }
    return 1;
}

// ----------------------------------------------

int verifycharformat(char * name){
    for (int i=0 ; name[i]!='\0' ; i++){
        if (!((name[i]>=65 && name[i]<=90) || (name[i]>=97 && name[i]<=122) || name[i]==32))
        return 0;
    }
    return 1;
}

// ----------------------------------------------

int main(){
    int size=10;
    char empidv[51],namev[51],desgv[51];

    struct empdata{
        char empid[5];
        char name[51];
        char desg[17];
    };  

    struct empdata empdataarr[size];
    for ( int i=0 ; i < size ; i++){

        printf("Enter the Records of employees :\n");
        printf("------------------------------------\n");

        printf("Record Number : %d\n",i+1);

    empid:

        printf("Enter the Employee ID (EEEE) :");
        gets(empidv);   
        fflush(stdin);

        if (verifyempid(empidv)==0){
            printf("\nEnter in a Valid Format :\n");
            goto empid;
        }
        strcpy(empdataarr[i].empid, empidv);

    name:

        printf("Enter the Name of Employee (Format Title Case) :");
        gets(namev);
        fflush(stdin);

        if (verifycharformat(namev)==0){
            printf("\n Enter in valid format ! \n");
            goto name; 
        }
        strcpy(empdataarr[i].name, namev);

    desg:

        printf("Enter the Designation (Format Title Case) :");
        gets(desgv);
        fflush(stdin);

        if (verifycharformat(desgv)==0){
            printf("\n Enter in valid format ! \n");
            goto desg; 
        }
        strcpy(empdataarr[i].desg, desgv);
    }

    printf("\n=== Employee Records ===\n");
    printf("\n--------------------------------\n");

    printf("| %-5s | %-20s |\n", "SrNo", "Name");

    for (int i=0; i<size; i++){
        printf("| %-5d | %-20s |\n", i+1, empdataarr[i].name);
    }

    printf("--------------------------------\n");

    return 0;
}
