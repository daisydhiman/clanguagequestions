// // 1. Write a program to enter 2 number from the users add them and display the answer, 
// again enter 2 number from the user subtract them and display the answer, 
// again enter 2 number from the user add them and display the answer, 
// again enter 2 number from the user multiply them and display the answer, 
// again enter 2 number from the user subtract them and display the answer, 
// again enter 2 number from the user multiply them and display the answer, 
// again enter 2 number from the user divide them and display the answer, 
// again enter 2 number from the user divide them and display the answer, 
// again enter 2 number from the user add them and display the answer ?

#include <stdio.h>
#include <conio.h>

int input(){  //INPUT FUNCTION 
    int a;
    printf("+ ================================================================= +\n");
    printf("\nEnter the Number : ");
    scanf("%d",&a);
    printf("\n");
    return a;
}

float inputf(){  //INPUT FUNCTION FLOAT
    float a;
    printf("+ ================================================================= +\n");
    printf("\nEnter the Number : ");
    scanf("%f",&a);
    printf("\n");
    return a;
}

int sum(int a,int b){  // SUM FUNCTION  
    return a+b;
}

int sub(int a,int b){  // SUBTRACTION FUNCTION  
    return a-b;
}

int pro(int a,int b){  // MULTIPLICATION FUNCTION  
    return a*b;
}

float div(float a,float b){  // DIVIDE FUNCTION  
    return a/b;
}



int main(){

    int a,b ; float c,d;

    a=input();
    b=input();
    printf("\n");
    printf("THE SUM OF %d and %d is : %d\n",a,b,sum(a,b));


    a=input();
    b=input();
    printf("\n");
    printf("THE DIFFERERNCE OF %d and %d is : %d\n",a,b,sub(a,b));

    a=input();
    b=input();
    printf("\n");
    printf("THE SUM OF %d and %d is : %d\n",a,b,sum(a,b));


    a=input();
    b=input();
    printf("\n");
    printf("THE PRODUCT OF %d and %d is : %d\n",a,b,pro(a,b));


    a=input();
    b=input();
    printf("\n");
    printf("THE DIFFERERNCE OF %d and %d is : %d\n",a,b,sub(a,b));

    a=input();
    b=input();
    printf("\n");
    printf("THE PRODUCT OF %d and %d is : %d\n",a,b,pro(a,b));


    c=inputf();
    d=inputf();
    printf("\n");
    d==0 ? printf("Cannot divide by 0 ") : printf("THE QUOTIENT WHEN %f is DIVIDED BY %f is : %f\n",c,d,div(c,d));


    c=inputf();
    d=inputf();
    printf("\n");
    d==0 ? printf("Cannot divide by 0 ") : printf("THE QUOTIENT WHEN %f is DIVIDED BY %f is : %f\n",c,d,div(c,d));

    a=input();
    b=input();
    printf("\n");
    printf("THE SUM OF %d and %d is : %d\n",a,b,sum(a,b));



    return 0;
}