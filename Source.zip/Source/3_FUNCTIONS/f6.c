// 6. Swap numbers using Call by function ?


#include <stdio.h>


void swap(int *x, int *y) {
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}


int main(){

    int a=6,b=10;
    printf("Befroe Swapping Num1 is %d and Num2 is %d \n",a,b);
    swap(&a,&b);
    printf("After Swapping Num1 is %d and Num2 is %d \n",a,b);

    return 0; 
}