// 4. Making following program using local and global variable ? Factorial , Reverse , Palindrome , Prime numbers, Armstrong , Fibonacci


#include <stdio.h>

int num;
int result;


void factorial() {
    result = 1;
    for (int i = 1; i <= num; i++) {
        result *= i;
    }
    printf("\nFactorial of %d = %d\n", num, result);
}

void reverse() {
    int temp = num;
    int rev = 0;
    while (temp > 0) {
        rev = rev * 10 + temp % 10;
        temp /= 10;
    }
    printf("Reverse of %d = %d\n", num, rev);
}

void palindrome() {
    int temp = num;
    int rev = 0;
    while (temp > 0) {
        rev = rev * 10 + temp % 10;
        temp /= 10;
    }
    if (rev == num)
        printf("%d is a Palindrome number.\n", num);
    else
        printf("%d is not a Palindrome number.\n", num);
}

void prime() {
    int flag = 0;
    if (num <= 1) flag = 1;
    for (int i = 2; i <= num / 2; i++) {
        if (num % i == 0) {
            flag = 1;
            break;
        }
    }
    if (flag == 0)
        printf("%d is a Prime number.\n", num);
    else
        printf("%d is not a Prime number.\n", num);
}

void armstrong() {
    int temp = num, sum = 0, digits = 0;
    while (temp > 0) {
        digits++;
        temp /= 10;
    }
    temp = num;
    while (temp > 0) {
        int d = temp % 10;
        int power = 1;
        for (int i = 0; i < digits; i++) {
            power *= d;
        }
        sum += power;
        temp /= 10;
    }
    if (sum == num)
        printf("%d is an Armstrong number.\n", num);
    else
        printf("%d is not an Armstrong number.\n", num);
}

void fibonacci() {
    int a = 0, b = 1, c;
    printf("Fibonacci series (%d terms): ", num);
    for (int i = 1; i <= num; i++) {
        printf("%d ", a);
        c = a + b;
        a = b;
        b = c;
    }
    printf("\n");
}


int main() {
    printf("Enter a number: ");
    scanf("%d", &num);

    printf("\n=== Operations on %d ===\n", num);
    factorial();
    reverse();
    palindrome();
    prime();
    armstrong();
    fibonacci();

    return 0;
}
