// 2. Write a program to enter 10 number from the user add the number and display the answer ?

#include <stdio.h>

int main(){
    
    int a, sum=0; 

    for (int i=0 ; i<10 ; i++){
        printf("Enter the Number %d Here :",i+1);
        scanf("%d",&a);
        sum+=a;
    }
    printf("\n+ ================================================================= +\n");
    printf("The sum of The NUMBERS You entered is : %d",sum);
    printf("\n+ ================================================================= +\n");

    return 0; 
}