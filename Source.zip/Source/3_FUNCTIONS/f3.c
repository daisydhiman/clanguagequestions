// 3. Write a program to return an array from function ?

#include <stdio.h>

int* arrayreturn(){

    static int arr[10]={1,2,3,4,5,6,7,8,9,0};

    return arr;
}

int main(){
    int *p,size=10;

    p=arrayreturn();

    for (int i=0; i<10 ; i++){
        printf("\n%d\n", *p );      
        p++;
    }
    return 0; 
}