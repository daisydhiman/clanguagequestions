// 5. Swap numbers using Call by address ?

#include <stdio.h>

int main(){
    int a=6,b=8;    
    int *p=&a,*q=&b, temp;

    temp=*p;
    *p=*q;
    *q=temp;

    printf("%d and %d ",*p,*q);




    return 0;
}