// 7. Make function for find out power of number, enter the number and power from user ?


#include <stdio.h>

int expo(int a,int pow){
    int ans=1;
    for (int i=1 ; i<=pow ; i++){
        ans*=a;
    }
    return ans;
}

int main(){
    int num,power;

    printf("Enter the Number : ");
    scanf("%d",&num);

    printf("Enter the Power to be Raised : ");
    scanf("%d",&power);

    printf("The final answer is %d",expo(num,power));
    return 0;
}