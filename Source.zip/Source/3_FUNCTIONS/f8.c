// 8. Make function for find out Cube a user entered number ?



#include <stdio.h>


int cube(int a){
    return a*a*a;
}
int main(){

    int a;
    printf("Enter the number : ");
    scanf("%d",&a);
    printf("The CUBE of %d is %d",a,cube(a));
    return 0;
}