//6. Write a program for printing your name on output screen but your name should blink 5 times
// TURBO C3 VERSION

#include <stdio.h>
#include <conio.h>
#include <dos.h>

void main() {
    char name[50];
    printf("Enter the Name : ");
    gets(name);
    for (int i=0 ; i<5 ; i++){
    printf("%s",name);
    clrscr();
    delay(1000);}

}
