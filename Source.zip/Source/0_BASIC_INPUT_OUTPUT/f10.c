//10. Write a program to store single quote and print that variable to show single quote on output screen.

#include <stdio.h>


int main() {
    char a='\'';
    printf("The Single Quote : %c",a);
    return 0;
}
