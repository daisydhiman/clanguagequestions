//13. Enter two character from user and print ASCII value ?

#include <stdio.h>
#include <conio.h>

int main(){
    int a,b;
    printf("Enter the charachter 1 : ");
    a=getche();
    printf("\nEnter the charachter 2 : ");
    b=getche();
    printf("\nThe ASCII value of %c is %d and %c is %d ",a,a,b,b);
    return 0;
}

