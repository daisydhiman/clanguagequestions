//12. Enter password display like ****** ?

#include <stdio.h>
#include <conio.h>
int main(){
    int size=7;
    char pass[size];
    
    printf("Enter the password : ");
    for (int i=0; i<size-1 ; i++){
    pass[i]=getch();
    printf("*");
    }

    pass[6]=0;

    printf("\nYour Password is : %s",pass);

    return 0;
}