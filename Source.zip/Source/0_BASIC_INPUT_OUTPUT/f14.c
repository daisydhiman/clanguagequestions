// 14.  Print all ASCII character 0 to 127 ?

# include <stdio.h>

int main(){
    int a = 128;
    for (int i=0 ; i<a ; i++)
    printf("Char number %d : The ASCII value of %c is %d\n",i+1,i,i);
    return 0;
}