//3. Write a program to read only 4 characters from the keyboard and display it on the screen in a separate line.

#include <stdio.h>
#include <conio.h>
int main(){
    
 
    char ch1, ch2, ch3, ch4;

    printf("Enter 4 characters: ");
    ch1=getche();ch2=getche();ch3=getche();ch4=getche();

    printf("\nYou entered:\n");
    printf("%c\n%c\n%c\n%c\n", ch1, ch2, ch3, ch4);

    return 0;

}