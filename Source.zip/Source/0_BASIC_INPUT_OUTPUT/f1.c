//1. Write a program to print the message: Today I made my first C Program.

#include <stdio.h>
int main(){
    
    printf("Today I made my first C Program.");
    
    
    return 0;

}