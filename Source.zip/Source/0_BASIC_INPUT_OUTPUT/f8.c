// 8. Write the program to display this output ? 
//#include<stdio.h> #include<conio.h> #include<dos.h> void main () { clrscr(); printf(“hello,welcome to c”); delay(5000); }

#include <stdio.h>

int main(){

    printf("#include<stdio.h> \ninclude<conio.h> \n#include<dos.h> \n\nvoid main () { \nclrscr(); \nprintf(\"hello,welcome to c\"); \ndelay(5000); \n}");

    return 0;
}