// 9. Write a program to print your name at the center of the page ?


#include <stdio.h>
#include <string.h>

int main(){
    
    char a[50];
    int namelen,offset,width=185,height=42; //$Host.UI.RawUI.WindowSize.Width &  $Host.UI.RawUI.WindowSize.Height ; the window size of powershell is variable 

    printf("Enter the Name :");
    gets(a);
    namelen=strlen(a);
    offset = (height/2);

    for (int i=0 ; i <offset; i++)
    printf("\n");

    for (int i=0 ; i<(width-namelen)/2 ; i++){
        printf(" ");
    }
    puts(a);
    
    for (int i=0 ; i <offset; i++)
    printf("\n");

    return 0;

}