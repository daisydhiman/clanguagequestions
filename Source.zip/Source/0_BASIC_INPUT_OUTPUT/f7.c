// 4. Write a program to print your name at center of the first line?
#include <stdio.h>
#include <conio.h>
#include <string.h>

int main(){
    
    char a[50];
    int namelen,width=185; //$Host.UI.RawUI.WindowSize.Width   ; the window size of powershell is variable 

    printf("Enter the Name :");
    gets(a);
    namelen=strlen(a);
    for (int i=0 ; i<(width-namelen)/2 ; i++){
        printf(" ");
    }
    puts(a);

    return 0;

}