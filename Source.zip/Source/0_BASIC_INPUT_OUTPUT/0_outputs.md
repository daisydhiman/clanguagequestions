# OUTPUTS BASIC INPUT OUTPUT 
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
//1. Write a program to print the message: Today I made my first C Program.

#include <stdio.h>
int main(){
    
    printf("Today I made my first C Program.");
    
    
    return 0;

}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f1.c -o f1; .\f1
Today I made my first C Program.

```

---

## 2. 
```c
// 2. Write a program to read a character from the keyboard and display it on the screen.

#include <stdio.h>
#include <conio.h>
int main(){
    
    char a; 
    printf("Enter a Char :");
    a=getche();
    printf("\nThe cahr you entered is : %c",a);
    
    
    return 0;

}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f2.c -o f2; .\f2
Enter a Char :d
The cahr you entered is : d

```

---

## 3.
```c
//3. Write a program to read only 4 characters from the keyboard and display it on the screen in a separate line.

#include <stdio.h>
#include <conio.h>
int main(){
    
 
    char ch1, ch2, ch3, ch4;

    printf("Enter 4 characters: ");
    ch1=getche();ch2=getche();ch3=getche();ch4=getche();

    printf("\nYou entered:\n");
    printf("%c\n%c\n%c\n%c\n", ch1, ch2, ch3, ch4);

    return 0;

}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f3.c -o f3; .\f3
Enter 4 characters: abcd
You entered:
a
b
c
d

```
---

## 4. 
```c
// 4. Write a program to print your name at center of the first line?
#include <stdio.h>
#include <conio.h>
#include <string.h>

int main(){
    
    char a[50];
    int namelen,width=185; //$Host.UI.RawUI.WindowSize.Width   ; the window size of powershell is variable

    printf("Enter the Name :");
    gets(a);
    namelen=strlen(a);
    for (int i=0 ; i<(width-namelen)/2 ; i++){
        printf(" ");
    }
    puts(a);

    return 0;

}

OUTPUT 

                                                                                          daisy

```

---

## 5 .

```c
//5. Write a program to store single quote and print that variable to show single quote on output screen.

#include <stdio.h>


int main() {
    char a='\'';
    printf("The Single Quote : %c",a);
    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f5.c -o f5; .\f5 
The Single Quote : '

```

---
## 6. 

```c

//6. Write a program for printing your name on output screen but your name should blink 5 times
// TURBO C3 VERSION

#include <stdio.h>
#include <conio.h>
#include <dos.h>

void main() {
    char name[50];
    printf("Enter the Name : ");
    gets(name);
    for (int i=0 ; i<5 ; i++){
    printf("%s",name);
    clrscr();
    delay(1000);}

}

OUTPUT



```

----
## 7. 

```c
// 7. Write a program to print your name at center of the first line?
#include <stdio.h>
#include <conio.h>
#include <string.h>

int main(){
    
    char a[50];
    int namelen,width=185; //$Host.UI.RawUI.WindowSize.Width   ; the window size of powershell is variable 

    printf("Enter the Name :");
    gets(a);
    namelen=strlen(a);
    for (int i=0 ; i<(width-namelen)/2 ; i++){
        printf(" ");
    }
    puts(a);

    return 0;

}


OUTPUT

                                                                                          daisy


```

---

## 8. 

```c
// 8. Write the program to display this output ? 
//#include<stdio.h> #include<conio.h> #include<dos.h> void main () { clrscr(); printf(“hello,welcome to c”); delay(5000); }

#include <stdio.h>

int main(){

    printf("#include<stdio.h> \ninclude<conio.h> \n#include<dos.h> \n\nvoid main () { \nclrscr(); \nprintf(\"hello,welcome to c\"); \ndelay(5000); \n}");

    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f8.c -o f8; .\f8 
#include<stdio.h> 
include<conio.h>
#include<dos.h>

void main () {
clrscr();
printf("hello,welcome to c");
delay(5000);
}

```

---

## 9. 

```c
// 9. Write a program to print your name at the center of the page ?


#include <stdio.h>
#include <string.h>

int main(){
    
    char a[50];
    int namelen,offset,width=185,height=42; //$Host.UI.RawUI.WindowSize.Width &  $Host.UI.RawUI.WindowSize.Height ; the window size of powershell is variable 

    printf("Enter the Name :");
    gets(a);
    namelen=strlen(a);
    offset = (height/2);

    for (int i=0 ; i <offset; i++)
    printf("\n");

    for (int i=0 ; i<(width-namelen)/2 ; i++){
        printf(" ");
    }
    puts(a);
    
    for (int i=0 ; i <offset; i++)
    printf("\n");

    return 0;

}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f9.c -o f9; .\f9
Enter the Name :daisy





















                                                                                          daisy






















```

----

## 10. 
```c
//10. Write a program to store single quote and print that variable to show single quote on output screen.

#include <stdio.h>


int main() {
    char a='\'';
    printf("The Single Quote : %c",a);
    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f10.c -o f10; .\f10 
The Single Quote : '



```

----
## 11.

```c
//11. Write a program for printing your name on output screen but your name should blink 5 times
// TURBO C3 VERSION

#include <stdio.h>
#include <conio.h>
#include <dos.h>

void main() {
    char name[50];
    printf("Enter the Name : ");
    gets(name);
    for (int i=0 ; i<5 ; i++){
    printf("%s",name);
    clrscr();
    delay(1000);}

}

OUTPUT

```
----

## 12. 

```c
//12. Enter password display like ****** ?

#include <stdio.h>
#include <conio.h>
int main(){
    int size=7;
    char pass[size];
    
    printf("Enter the password : ");
    for (int i=0; i<size-1 ; i++){
    pass[i]=getch();
    printf("*");
    }

    pass[6]=0;

    printf("\nYour Password is : %s",pass);

    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f12.c -o f12; .\f12
Enter the password : ******
Your Password is : abcdef


```

----
## 13.

```c
//13. Enter two character from user and print ASCII value ?

#include <stdio.h>
#include <conio.h>

int main(){
    int a,b;
    printf("Enter the charachter 1 : ");
    a=getche();
    printf("\nEnter the charachter 2 : ");
    b=getche();
    printf("\nThe ASCII value of %c is %d and %c is %d ",a,a,b,b);
    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f13.c -o f13; .\f13 
Enter the charachter 1 : a
Enter the charachter 2 : b
The ASCII value of a is 97 and b is 98

```

----

## 14. 
```c

// 14.  Print all ASCII character 0 to 127 ?

# include <stdio.h>

int main(){
    int a = 128;
    for (int i=0 ; i<a ; i++)
    printf("Char number %d : The ASCII value of %c is %d\n",i+1,i,i);
    return 0;
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\0_basic_input_output> gcc f14.c -o f14; .\f14
Char number 1 : The ASCII value of  is 0
Char number 2 : The ASCII value of  is 1
Char number 3 : The ASCII value of  is 2
Char number 4 : The ASCII value of  is 3
Char number 5 : The ASCII value of  is 4
Char number 6 : The ASCII value of  is 5
Char number 7 : The ASCII value of  is 6
Char number 8 : The ASCII value of  is 7
Char number 9 : The ASCII value of is 8
Char number 10 : The ASCII value of      is 9
Char number 11 : The ASCII value of
 is 10
Char number 12 : The ASCII value of
 is 11
Char number 13 : The ASCII value of
 is 12
 is 13umber 14 : The ASCII value of
Char number 15 : The ASCII value of  is 14
Char number 16 : The ASCII value of  is 15
Char number 17 : The ASCII value of  is 16
Char number 18 : The ASCII value of  is 17
Char number 19 : The ASCII value of  is 18
Char number 20 : The ASCII value of  is 19
Char number 21 : The ASCII value of  is 20
Char number 22 : The ASCII value of  is 21
Char number 23 : The ASCII value of  is 22
Char number 24 : The ASCII value of  is 23
Char number 25 : The ASCII value of  is 24
Char number 26 : The ASCII value of  is 25
Char number 27 : The ASCII value of ␦ is 26
Char number 28 : The ASCII value of s 27
Char number 29 : The ASCII value of  is 28
Char number 30 : The ASCII value of  is 29
Char number 31 : The ASCII value of  is 30
Char number 32 : The ASCII value of  is 31
Char number 33 : The ASCII value of   is 32
Char number 34 : The ASCII value of ! is 33
Char number 35 : The ASCII value of " is 34
Char number 36 : The ASCII value of # is 35
Char number 37 : The ASCII value of $ is 36
Char number 38 : The ASCII value of % is 37
Char number 39 : The ASCII value of & is 38
Char number 40 : The ASCII value of ' is 39
Char number 41 : The ASCII value of ( is 40
Char number 42 : The ASCII value of ) is 41
Char number 43 : The ASCII value of * is 42
Char number 44 : The ASCII value of + is 43
Char number 45 : The ASCII value of , is 44
Char number 46 : The ASCII value of - is 45
Char number 47 : The ASCII value of . is 46
Char number 48 : The ASCII value of / is 47
Char number 49 : The ASCII value of 0 is 48
Char number 50 : The ASCII value of 1 is 49
Char number 51 : The ASCII value of 2 is 50
Char number 52 : The ASCII value of 3 is 51
Char number 53 : The ASCII value of 4 is 52
Char number 54 : The ASCII value of 5 is 53
Char number 55 : The ASCII value of 6 is 54
Char number 56 : The ASCII value of 7 is 55
Char number 57 : The ASCII value of 8 is 56
Char number 58 : The ASCII value of 9 is 57
Char number 59 : The ASCII value of : is 58
Char number 60 : The ASCII value of ; is 59
Char number 61 : The ASCII value of < is 60
Char number 62 : The ASCII value of = is 61
Char number 63 : The ASCII value of > is 62
Char number 64 : The ASCII value of ? is 63
Char number 65 : The ASCII value of @ is 64
Char number 66 : The ASCII value of A is 65
Char number 67 : The ASCII value of B is 66
Char number 68 : The ASCII value of C is 67
Char number 69 : The ASCII value of D is 68
Char number 70 : The ASCII value of E is 69
Char number 71 : The ASCII value of F is 70
Char number 72 : The ASCII value of G is 71
Char number 73 : The ASCII value of H is 72
Char number 74 : The ASCII value of I is 73
Char number 75 : The ASCII value of J is 74
Char number 76 : The ASCII value of K is 75
Char number 77 : The ASCII value of L is 76
Char number 78 : The ASCII value of M is 77
Char number 79 : The ASCII value of N is 78
Char number 80 : The ASCII value of O is 79
Char number 81 : The ASCII value of P is 80
Char number 82 : The ASCII value of Q is 81
Char number 83 : The ASCII value of R is 82
Char number 84 : The ASCII value of S is 83
Char number 85 : The ASCII value of T is 84
Char number 86 : The ASCII value of U is 85
Char number 87 : The ASCII value of V is 86
Char number 88 : The ASCII value of W is 87
Char number 89 : The ASCII value of X is 88
Char number 90 : The ASCII value of Y is 89
Char number 91 : The ASCII value of Z is 90
Char number 92 : The ASCII value of [ is 91
Char number 93 : The ASCII value of \ is 92
Char number 94 : The ASCII value of ] is 93
Char number 95 : The ASCII value of ^ is 94
Char number 96 : The ASCII value of _ is 95
Char number 97 : The ASCII value of ` is 96
Char number 98 : The ASCII value of a is 97
Char number 99 : The ASCII value of b is 98
Char number 100 : The ASCII value of c is 99
Char number 101 : The ASCII value of d is 100
Char number 102 : The ASCII value of e is 101
Char number 103 : The ASCII value of f is 102
Char number 104 : The ASCII value of g is 103
Char number 105 : The ASCII value of h is 104
Char number 106 : The ASCII value of i is 105
Char number 107 : The ASCII value of j is 106
Char number 108 : The ASCII value of k is 107
Char number 109 : The ASCII value of l is 108
Char number 110 : The ASCII value of m is 109
Char number 111 : The ASCII value of n is 110
Char number 112 : The ASCII value of o is 111
Char number 113 : The ASCII value of p is 112
Char number 114 : The ASCII value of q is 113
Char number 115 : The ASCII value of r is 114
Char number 116 : The ASCII value of s is 115
Char number 117 : The ASCII value of t is 116
Char number 118 : The ASCII value of u is 117
Char number 119 : The ASCII value of v is 118
Char number 120 : The ASCII value of w is 119
Char number 121 : The ASCII value of x is 120
Char number 122 : The ASCII value of y is 121
Char number 123 : The ASCII value of z is 122
Char number 124 : The ASCII value of { is 123
Char number 125 : The ASCII value of | is 124
Char number 126 : The ASCII value of } is 125
Char number 127 : The ASCII value of ~ is 126
Char number 128 : The ASCII value of  is 127

```


----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---