// 2. Write a program to read a character from the keyboard and display it on the screen.

#include <stdio.h>
#include <conio.h>
int main(){
    
    char a; 
    printf("Enter a Char :");
    a=getche();
    printf("\nThe cahr you entered is : %c",a);
    
    
    return 0;

}