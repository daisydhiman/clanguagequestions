# INDEX OF QUESTIONS 


### 0 - BASIC INPUT OUTPUT 

1. Write a program to print the message: Today I made my first C Program.

2. Write a program to read a character from the keyboard and display it on the screen.

3. Write a program to read only 4 characters from the keyboard and display it on the screen in a separate line.

4. Write a program to print your name at center of the first line?

5. Write a program to store single quote and print that variable to show single quote on output screen.

6. Write a program for printing your name on output screen but your name should blink 5 times

7. Write a program to print your name at center of the first line ?

8. Write the program to display this output ? #include<stdio.h> #include<conio.h> #include<dos.h> void main () { clrscr(); printf(“hello,welcome to c”); delay(5000); }

9. Write a program to print your name at the center of the page ?

10. Write a program to store single quote and print that variable to show single quote on output screen ?

11. Write a program for printing your name on output screen but your name should blink 5 time ?

12. Enter password display like ****** ?

13. Enter two character from user and print ASCII value ?

14. Print all ASCII character 0 to 127 ?

---

### 1 - DECISION CONTROL STRUCTURE 

1. Write a program to enter the number from the user and check it is positive or negative or 0 (zero) ?

2. Enter a number from user and check it is odd or even ?

3. Enter a number from the user and check that it is of 1 digit or 2 digit or 3 digit or 4 digit or 5 digit ?

4. Enter a number from the user if the number is between 0 to 40 then we will print fail if the number is between 40 to 60 then we will print C grade ,if the number is between 60 to 80 than we will print B grade ,if the number is between 80 to 100 then we will print A grade and rest all number are invalid ?

5. Enter a number from the user and check it is a decimal number or not ?

6. Enter a number from the user if it is a negative then convert into positive and if it is positive then convert into negative often that print the number ?

7. Enter a character from the user and check that it is an alphabet ?

8. Enter a number from the user if the number is negative then square the number and if it is positive then increment the number 20 times ?

9. Enter the number from the user it the number is negative or positive and find out of that number ?

10. Enter two number from user and check which is the greater number and print the greater number ?

11. Enter a number from user and check it is divisible by 4 or not ?

12. Enter a four characters from users and check they are equal or not ?

13. Enter three numbers from users and tell which is greater ?

14. Enter a number from the user if the user enters 30 then print the month in which we have 30 days. If the enter 31 then print the month 31 days for 28, 29 print the month else everything is invalid ?

15. Enter one digit number from user and print in words ?

16. Enter two characters from user and check both are same or not, if not same then find out difference between them ?

17. Enter three numbers from user and which is greater ?

18. Enter two digit number from user and print it in word (like 50 will be five zero) ?

19. Enter a character from user and it is in upper case, lower case, special characters or numbers ?

20. Enter the year from user and check its leap year or not ?

21. Enter date, month, year and check it is valid date or not ?

22. Enter current date of DOB of user and find out difference ?

23. Write a program to calculate area and perimeter of rectangle ?

---
### 2 - FILE HANDLING 


---
### 3 - FUNCTIONS 

1. Write a program to enter 2 number from the users add them and display the answer, again enter 2 number from the user subtract them and display the answer, again enter 2 number from the user add them and display the answer, again enter 2 number from the user multiply them and display the answer, again enter 2 number from the user subtract them and display the answer, again enter 2 number from the user multiply them and display the answer, again enter 2 number from the user divide them and display the answer, again enter 2 number from the user divide them and display the answer, again enter 2 number from the user add them and display the answer ?

2. Write a program to enter 10 number from the user add the number and display the answer ?

3. Write a program to return an array from function ?

4. Making following program using local and global variable ? Factorial , Reverse , Palindrome , Prime numbers, Armstrong , Fibonacci

5. Swap numbers using Call by address ?

6. Swap numbers using Call by function ?

7. Make function for find out power of number, enter the number and power from user ?

8. Make function for find out Cube a user entered number ?

---
### 4 - ITERATIVE CONTROL STRUCTURE (LOOPS) 

1. Enter a number from the user and find out the binary of that number ?

2. Enter a number from the user and check that the number is divisible by any prime number or not ?

3. Enter a number from the user and check it is a prime number or not ?

4. Enter a number from the user and print all digit of the number in separate line ?

5. Write a program to print your name 1 lakh times ?

6. Write a program to print a series 1 to 1 lakh ?

7. Enter a number from the user and print the series from 1 to that number ?

8. Enter a number from the user and print that number 100 time ?

9. Write a program print all the odd number between 1 to 100 ?

10. Write a program print the table of 4 in the format given as below (till 20)? 4*1=4 and so on

11. Enter the number from user and reverse the number?

12. Enter a number from the user if the user enter 1 then you will perform addition operation by entering 2 number from user add it and display answer. if user enter 2 then subtract or if user enter 3 then multiply or if user enter 4 then divide or if user enter 5 then modulo or if any other number then print invalid .if user want to quit the program then user will enter Q. ?

13. Enter the number from user and check its palindrome or not?

14. Enter two numbers from users, one is base and second is power. Write the result ?

15. Enter a number from user and print first digit of number ?

16. Enter a number from user and print total from 0 to that number ?

17. Enter a number from user and find out factorial of that number ?

18. Enter two numbers from user and print range from first number to second number ?

19. Enter password from user maximum 20 digits / character press enter key if you want to exit ?

20. Write a program to print the counting 1 to 100 with one second delay ?

21. Write a program to find out the Fibonacci series/ 1 to 100 (like 0 1 1 2 3 5 8 13………..) ?

22. Enter a character from user and that character should be alphabet ?

23. Check numbers from user is palindrome or not ?

24. Enter a number from user and check it is Armstrong number or not ?

25. Enter a number from user and check it is Armstrong number or not ?

---
### 5 - ITERATIVE CONTROL STRUCTURE (NESTED LOOPS) 

1. Write a program print the pattern on the screen i.e. ? 11111 11111 11111

---
### 6 - MULTI-DIMENSION ARRAYS 

1. Enter the four number from user and print it into matrix

2. Enter the matrix from and transpose them ?

3. Enter 2 matrix from user and add them ?

4. Enter 2 matrix from user and subtract them ?

5. Enter 2 matrix from user and multiply them ?

---
### 7 - OPERATORS 

1. Write a program to show that example of pre-increment ?

2. Write a program to show that example of post-increment ?

3. Write a program to show that example of pre-decrement ?

4. Write a program to show that example of post-decrement ?

5. Write a program to enter 2 numbers from user add the number and show the answer , again take 2 number from user subtract the number display the answer ,again take 2 number from user multiply the number display the answer and ,again take 2 number from the user divide the number display the answer ,again take 2 number find the remainder and display the answer ?

6. Write a program to enter a number from the user ,the length of the number is depend on the user ,programmer should print the last digit of number ?

7. Enter a decimal number from the user (float) and print the right hand side of the decimal point ?

8. Enter a number from user and find out cube of numbers ?

9. Enter float number from user and round of the number ?

10. Enter a lower case character from user and print it into upper case ?

11. Enter marks of students and calculate average of student’s marks ?

12. Calculate simple interest = (P x R x T)/ 100

---
### 8 - POINTERS 


---
### 9 - RECURSION 


---
### 10 - SINGLE DIMENSION ARRAYS 

1. Enter an array from user and display all the value ?

2. Enter an array from user and print the array in reverse order ?

3. Enter an array from user and copy the array into second array ?

4. Enter an array from user and copy it into another array in reverse order ?

5. Enter an array from user and print the number which is even ?

6. Enter an array from user and print the number which is positive ?

7. Enter an array from user and square all the values of array ?

8. Enter 5 values of array from user and print odd number of array ?

9. Enter 5 values of array from user and add all values ?

10. Enter 5 values of array from user, enter a value from user and search this value in array, if value is found then print “found” or not then print “not found”?

11. Enter five values of array and sort in ascending order ?

12. Find maximum values of array ?

13. Find minimum values of array ?

---
### 11 - STRINGS 

1. Enter a string from user and convert in uppercase ?

2. Enter a string from user and convert into lowercase ?

3. Enter a string from user and convert into sentence case ?

4. Enter a string from user and convert into title case ?

5. Enter a string from user and convert into toggle case ?

6. Enter a string from user and final length of the string ?

7. Enter a string from user and compare those string ?

8. Enter a string from user and concatenate the string ?

9. Enter a string from user and copy that string into another string ?

10. Enter the string from user ,enter a number from user ,if the user enter 0 then you will print first character of string ,if the user enter 1 then you will print second character of string ,if user enter 2 then you will print third character of string ,if user enter 3 then you point fourth character of string and if out of string then you will print out of bound ?

11. Enter the string from user and print each character in new line ?

12. Enter the string from user and copy reverse order into another string ?

13. Enter two string from user and print difference each character ?

14. Enter the string from user and enter a character , it is exist or not ?

15. Enter the string from user and enter a character if it is exist then print the bound number ?

16. Enter the string from user and count all vowels ?

17. Enter the string from user and enter bound number and print character on that bound ?

18. String palindrome example (using reverse) ?

19. Enter the data from user the data consist of roll no. ,name ,class , marks of 5 subjects ?

---
### 12 - STRUCTURES 

1. Create structure of employee which there is emp.ID, name, designation of 50 employees from user, print details in tabular form ?

2. Create structure of employee which there is emp.ID, name, designation of 50 employees from user and print only name of the employee ?

3. Create structure of employee which there is emp.ID, name, designation of 50 employees from user and print name character with emp.ID in tabular form ?

4. Enter student details like roll name, fee, DOB and print all the detail by ascending order of roll number ?

---
### 13 - UNION


---
