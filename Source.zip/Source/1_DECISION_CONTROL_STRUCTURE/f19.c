// 19. Enter a character from user and it is in upper case, lower case, special characters or numbers ?

#include <stdio.h>
#include <conio.h>

int main() {
    char a;
    printf("Enter a character : ");
    a = getche();

    if (a >= 65 && a <= 90)
        printf("\nIt is an uppercase letter");
    else if (a >= 97 && a <= 122)
        printf("\nIt is a lowercase letter");
    else if (a >= 48 && a <= 57)
        printf("\nIt is a number");
    else
        printf("\nIt is a special character");

    return 0;
}
