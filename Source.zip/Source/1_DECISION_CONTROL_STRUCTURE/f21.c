// 21. Enter date, month, year and check it is valid date or not ?

#include <stdio.h>

int main() {
    int d, m, y, days;

    printf("Enter the date : ");
    scanf("%d", &d);

    printf("Enter month : ");
    scanf("%d", &m);

    printf("Enter the year : ");
    scanf("%d", &y);

    if (y < 1 || m < 1 || m > 12 || d < 1) {
        printf("Enter a valid date");
        return 0;
    }

    switch (m) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            days = 31;
            break;
        case 4: case 6: case 9: case 11:
            days = 30;
            break;
        case 2:
            if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
                days = 29;
            else
                days = 28;
            break;
        default:
            printf("invalid month");
            return 0;
    }

    if (d > days)
        printf("Enter a valid no of days");
    else {
        printf("%d-%d-%d is  a valid date", d, m, y);
    }

    return 0;
}
