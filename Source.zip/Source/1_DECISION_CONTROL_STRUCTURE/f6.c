// 6. 6. Enter a number from the user if it is a negative then convert into positive and
//  if it is positive then convert into negative often that print the number ?


#include <stdio.h>

int main() {
    int n;
    printf("Enter the number : ");
    scanf("%d", &n);

    if (n==0)
    printf("It is Zero ");
    else if (n>0)
    printf("The -ve of %d is : %d",n,-n);
    
    else if (n<0)
    printf("The +ve of %d is : %d",n,-n);
    


    return 0;
}
