// 5. Enter a number from the user and check it is a decimal number or not ?

#include <stdio.h>

int main() {
    float a;
    printf("Enter the  number : ");
    scanf("%f", &a);

    if (a == (int)a)
        printf("It is not decimal number\n");
    else
        printf("It is decimal number\n");

    return 0;
}
