// 7. Enter a character from the user and check that it is an alphabet ?

#include <stdio.h>
#include <conio.h>

int main(){
    char a;
    printf("Enbter the char : ");
    a=getche();

    if ((a>=65 && a<=90 ) || (a>=97 && a<=122))
    printf("\n%c is a alphabet ",a);
    else 
    printf("\n%c is not a  alphabet ",a);
    

    return 0;

}