// 22. Enter current date of DOB of user and find out difference ?

