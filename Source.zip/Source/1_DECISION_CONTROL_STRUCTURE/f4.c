// // 4. Enter a number from the user if the number is between 0 to 40 then we will print fail 
// if the number is between 40 to 60 then we will print C grade ,
// if the number is between 60 to 80 than we will print B grade ,
// if the number is between 80 to 100 then we will print A grade and rest all number are invalid ?


# include <stdio.h>

int main(){
     int a ;
    printf("Enter the number : ");
    scanf("%d",&a);

    if (a >= 0 && a < 40)
        printf("Fail\n");
    else if (a >= 40 && a < 60)
        printf("C Grade\n");
    else if (a >= 60 && a < 80)
        printf("B Grade\n");
    else if (a >= 80 && a <= 100)
        printf("A Grade\n");
    else
        printf("Enter the mark\n");

    return 0;



    return 0;
}