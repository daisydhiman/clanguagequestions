// 14. Enter a number from the user if the user enters 30 then print the month in which we have 30 days.
//  If the enter 31 then print the month 31 days for 28, 29 print the month else everything is invalid ?

#include <stdio.h>

int main() {
    int a;

    printf("Enter number of days : ");
    scanf("%d", &a);

    if (a == 31)
        printf("jan mar may jul aug oct dec");
    else if (a == 30)
        printf("apr jun sep nov");
    else if (a == 28 || a == 29)
        printf("feb");
    else
        printf("invalid");

    return 0;
}
