// 11. Enter a number from user and check it is divisible by 4 or not ?

#include <stdio.h>

int main() {
    int a;
    printf("Enter the number : ");
    scanf("%d", &a);

    if (a % 4 == 0)
        printf("%d is divisible by 4\n", a);
    else
        printf("%d is not divisible by 4\n", a);

    return 0;
}
