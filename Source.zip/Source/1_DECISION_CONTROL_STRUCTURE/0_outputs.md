# DESICION CONTROL
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
// 1. Write a program to enter the number from the user and check it is positive or negative or 0 (zero) ?

# include <stdio.h>

int main(){
    int a;
    printf("Enter the number :");
    scanf("%d",&a);

    a==0 ? printf("The number is ZERO") : a>0 ? printf("The number is +ve ") : printf("The number is -ve") ; 

    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f1.c -o f1; .\f1
Enter the number :3
The number is +ve 

```

---

## 2. 
```c
//2. Enter a number from user and check it is odd or even ?

#include <stdio.h>

int main(){
    int a;
    printf("Enter the number :");
    scanf("%d",&a);
    
    a%2==0 ? printf("The number is EVEN") : printf("The number is ODD");

    return 0; 
}

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f2.c -o f2; .\f2
Enter the number :323
The number is ODD

```

---

## 3.
```c
// 3. Enter a number from the user and check that it is of 1 digit or 2 digit or 3 digit or 4 digit or 5 digit ?

#include <stdio.h>

int main() {
    int n;
    printf("Enter the number : ");
    scanf("%d", &n);

    if (n < 0)
        n = -n;  

    if (n >= 0 && n <= 9)
        printf("It is a 1-digit number\n");
    else if (n >= 10 && n <= 99)
        printf("It is a 2-digit number\n");
    else if (n >= 100 && n <= 999)
        printf("It is a 3-digit number\n");
    else if (n >= 1000 && n <= 9999)
        printf("It is a 4-digit number\n");
    else if (n >= 10000 && n <= 99999)
        printf("It is a 5-digit number\n");
    else
        printf("It is more than 5 digits\n");

    return 0;
}


OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f3.c -o f3; .\f3
Enter the number : 32324
It is a 5-digit number
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f3.c -o f3; .\f3
Enter the number : 343
It is a 3-digit number

```
---

## 4. 
```c
// // 4. Enter a number from the user if the number is between 0 to 40 then we will print fail 
// if the number is between 40 to 60 then we will print C grade ,
// if the number is between 60 to 80 than we will print B grade ,
// if the number is between 80 to 100 then we will print A grade and rest all number are invalid ?


# include <stdio.h>

int main(){
     int a ;
    printf("Enter the number : ");
    scanf("%d",&a);

    if (a >= 0 && a < 40)
        printf("Fail\n");
    else if (a >= 40 && a < 60)
        printf("C Grade\n");
    else if (a >= 60 && a < 80)
        printf("B Grade\n");
    else if (a >= 80 && a <= 100)
        printf("A Grade\n");
    else
        printf("Enter the mark\n");

    return 0;



    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f4.c -o f4; .\f4 
Enter the number : 45 
C Grade

```

---

## 5 .

```c
// 5. Enter a number from the user and check it is a decimal number or not ?

#include <stdio.h>

int main() {
    float a;
    printf("Enter the  number : ");
    scanf("%f", &a);

    if (a == (int)a)
        printf("It is not decimal number\n");
    else
        printf("It is decimal number\n");

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f5.c -o f5; .\f5 
Enter the  number : 233
It is not decimal number
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f5.c -o f5; .\f5
Enter the  number : 323.3
It is decimal number

```

---
## 6. 

```c
// 6. Enter a number from the user if it is a negative then convert into positive and
//  if it is positive then convert into negative often that print the number ?


#include <stdio.h>

int main() {
    int n;
    printf("Enter the number : ");
    scanf("%d", &n);

    if (n==0)
    printf("It is Zero ");
    else if (n>0)
    printf("The -ve of %d is : %d",n,-n);
    
    else if (n<0)
    printf("The +ve of %d is : %d",n,-n);
    


    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f6.c -o f6; .\f6
Enter the number : 3434
The -ve of 3434 is : -3434
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f6.c -o f6; .\f6
Enter the number : -434
The +ve of -434 is : 434

```

----
## 7. 

```c
// 7. Enter a character from the user and check that it is an alphabet ?

#include <stdio.h>
#include <conio.h>

int main(){
    char a;
    printf("Enbter the char : ");
    a=getche();

    if ((a>=65 && a<=90 ) || (a>=97 && a<=122))
    printf("\n%c is a alphabet ",a);
    else 
    printf("\n%c is not a  alphabet ",a);
    

    return 0;

}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f7.c -o f7; .\f7
Enbter the char : f
f is a alphabet
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f7.c -o f7; .\f7
Enbter the char : 3
3 is not a  alphabet


```

---

## 8. 

```c
// 8. Enter a number from the user 
// if the number is negative then square the number and if it is positive then increment the number 20 times ?

#include <stdio.h>

int main() {
    int a;
    printf("Enter the  number : ");
    scanf("%d", &a);

    if (a < 0)
        printf("Number is -ve ,  Square :  %d\n", a * a);
    else
        printf("Number is +ve , after incrementing 20 times : %d\n", a + 20);

    return 0;
}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f8.c -o f8; .\f8
Enter the  number : 4343
Number is +ve , after incrementing 20 times : 4363
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f8.c -o f8; .\f8
Enter the  number : -43
Number is -ve ,  Square :  1849

```

---

## 9. 

```c
// 9. Enter the number from the user it the number is negative or positive and find out of that number ?

#include <stdio.h>

int main() {
    int a;
    printf("Enter the number : ");
    scanf("%d", &a);

    if (a > 0)
        printf("%d is a positive number\n", a);
    else if (a < 0)
        printf("%d is a negative number\n", a);
    else
        printf("The number is zero\n");


    return 0;
}


OUTPUT

S D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f9.c -o f9; .\f9
Enter the number : 343
343 is a positive number
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f9.c -o f9; .\f9
Enter the number : -43
-43 is a negative number
```

----

## 10. 
```c
// 10. Enter two number from user and check which is the greater number and print the greater number ?


#include <stdio.h>

int main() {
    int a, b;
    printf("Enter first number : ");
    scanf("%d", &a);

    printf("Enter second number : ");
    scanf("%d", &b);

    if (a > b)
        printf("%d is greater\n", a);
    else if (b > a)
        printf("%d is greater\n", b);
    else
        printf("Both  are equal\n");

    return 0;
}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f10.c -o f10; .\f10
Enter first number : 434
Enter second number : 45
434 is greater
```

----
## 11.

```c
// 11. Enter a number from user and check it is divisible by 4 or not ?

#include <stdio.h>

int main() {
    int a;
    printf("Enter the number : ");
    scanf("%d", &a);

    if (a % 4 == 0)
        printf("%d is divisible by 4\n", a);
    else
        printf("%d is not divisible by 4\n", a);

    return 0;
}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f11.c -o f11; .\f11
Enter the number : 233
233 is not divisible by 4

```
----

## 12. 

```c
// 12. Enter a four characters from users and check they are equal or not ?

#include <stdio.h>

int main() {
    char a, b, c, d;

    printf("Enter 1st character : ");
    scanf(" %c", &a);

    printf("Enter 2nd character : ");
    scanf(" %c", &b);

    printf("Enter 3rd character : ");
    scanf(" %c", &c);

    printf("Enter 4th character : ");
    scanf(" %c", &d);

    if (a == b && b == c && c == d)
        printf("All characters are equal\n");
    else
        printf("All characters are not equal\n");

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f12.c -o f12; .\f12
Enter 1st character : d
Enter 2nd character : d
Enter 3rd character : f
Enter 4th character : d
All characters are not equal


```

----
## 13.

```c
// 13. Enter three numbers from users and tell which is greater ?

#include <stdio.h>

int main() {
    int a, b, c;

    printf("Enter first number : ");
    scanf("%d", &a);

    printf("Enter second number : ");
    scanf("%d", &b);

    printf("Enter third number : ");
    scanf("%d", &c);

    if (a > b && a > c)
        printf("First number is greater\n");
    else if (b > a && b > c)
        printf("Second number is greater\n");
    else
        printf("Third number is greater\n");

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f13.c -o f13; .\f13
Enter first number : 3
Enter second number : 5
Enter third number : 3
Second number is greater

```

----

## 14. 
```c
// 14. Enter a number from the user if the user enters 30 then print the month in which we have 30 days.
//  If the enter 31 then print the month 31 days for 28, 29 print the month else everything is invalid ?

#include <stdio.h>

int main() {
    int a;

    printf("Enter number of days : ");
    scanf("%d", &a);

    if (a == 31)
        printf("jan mar may jul aug oct dec");
    else if (a == 30)
        printf("apr jun sep nov");
    else if (a == 28 || a == 29)
        printf("feb");
    else
        printf("invalid");

    return 0;
}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f14.c -o f14; .\f14 
Enter number of days : 45
invalid
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f14.c -o f14; .\f14
Enter number of days : 31
jan mar may jul aug oct dec

```

---
## 15 .

```c
// 15. Enter one digit number from user and print in words ?

#include <stdio.h>

int main() {
    int a;

    printf("Enter one digit number : ");
    scanf("%d", &a);

    switch(a) {
        case 0: printf("zero"); break;
        case 1: printf("one"); break;
        case 2: printf("two"); break;
        case 3: printf("three"); break;
        case 4: printf("four"); break;
        case 5: printf("five"); break;
        case 6: printf("six"); break;
        case 7: printf("seven"); break;
        case 8: printf("eight"); break;
        case 9: printf("nine"); break;
        default: printf("invalid");
    }

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f15.c -o f15; .\f15
Enter one digit number : 4
four

```
---

## 16. 
```c
// 16. Enter two characters from user and check both are same or not, 
// if not same then find out difference between them ?

#include <stdio.h>
#include <conio.h>

int main() {
    char a, b;

    printf("Enter first character : ");
    a = getche();

    printf("\nEnter second character : ");
    b = getche();

    if (a == b)
        printf("\nBoth are same");
    else
        printf("\nBoth are different, difference is : %d", a - b);

    return 0;
}



OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f16.c -o f16; .\f16
Enter first character : f
Enter second character : h
Both are different, difference is : -2
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f16.c -o f16; .\f16
Enter first character : f
Enter second character : f
Both are same


```

---

## 17. 
```c

// 17. Enter three numbers from user and which is greater ?

#include <stdio.h>

int main() {
    int a, b, c;

    printf("Enter first number : ");
    scanf("%d", &a);

    printf("Enter second number : ");
    scanf("%d", &b);

    printf("Enter third number : ");
    scanf("%d", &c);

    if (a > b && a > c)
        printf("First number is greater\n");
    else if (b > a && b > c)
        printf("Second number is greater\n");
    else
        printf("Third number is greater\n");

    return 0;
}


OUTPUT 

S D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f17.c -o f17; .\f17
Enter first number : 5
Enter second number : 6
Enter third number : 7
Third number is greater


```

----

## 18 . 

```c
// 18. Enter two digit number from user and print it in word (like 50 will be five zero) ?

#include <stdio.h>
#include <conio.h>

int main() {
    char num[3];
    printf("Enter two digit number : ");

    num[0]=getche();
    num[1]=getche();
    printf("\n");

    for (int i = 0; i < 2; i++) {
        switch (num[i]) {
            case '0': printf("zero "); break;
            case '1': printf("one "); break;
            case '2': printf("two "); break;
            case '3': printf("threee "); break;
            case '4': printf("four "); break;
            case '5': printf("five "); break;
            case '6': printf("six "); break;
            case '7': printf("seven "); break;
            case '8': printf("eight "); break;
            case '9': printf("nine "); break;
            default: printf("invalid "); break;
        }
    }

    return 0;
}



OUTPUT 


PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f18.c -o f18; .\f18
Enter two digit number : 45
four five


```

---

## 19.

```c

// 19. Enter a character from user and it is in upper case, lower case, special characters or numbers ?

#include <stdio.h>
#include <conio.h>

int main() {
    char a;
    printf("Enter a character : ");
    a = getche();

    if (a >= 65 && a <= 90)
        printf("\nIt is an uppercase letter");
    else if (a >= 97 && a <= 122)
        printf("\nIt is a lowercase letter");
    else if (a >= 48 && a <= 57)
        printf("\nIt is a number");
    else
        printf("\nIt is a special character");

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f19.c -o f19; .\f19
Enter a character : g
It is a lowercase letter

```

---


## 20 . 


```c
// 20. Enter the year from user and check its leap year or not ?

#include <stdio.h>

int main() {
    int year;

    printf("Enter the year : ");
    scanf("%d", &year);

    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        printf("Leap year");
    else
        printf("Not a leap year");

    return 0;
}


OUTPUTS

PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f20.c -o f20; .\f20
Enter the year : 3445
Not a leap year
PS D:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f20.c -o f20; .\f20
Enter the year : 2000
Leap year



```

---


## 21.

```c
// 21. Enter date, month, year and check it is valid date or not ?

#include <stdio.h>

int main() {
    int d, m, y, days;

    printf("Enter the date : ");
    scanf("%d", &d);

    printf("Enter month : ");
    scanf("%d", &m);

    printf("Enter the year : ");
    scanf("%d", &y);

    if (y < 1 || m < 1 || m > 12 || d < 1) {
        printf("Enter a valid date");
        return 0;
    }

    switch (m) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            days = 31;
            break;
        case 4: case 6: case 9: case 11:
            days = 30;
            break;
        case 2:
            if ((y% 4 == 0 && y% 100 != 0) || (y% 400 == 0))
                days = 29;
            else
                days = 28;
            break;
        default:
            printf("invalid month");
            return 0;
    }

    if (d > days)
        printf("Enter a valid no of days");
    else {
        printf("%d-%d-%d is  a valid date", d, m, y);
    }

    return 0;
}


OUTPUTS

PS E:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f21.c -o f21; .\f21
Enter the date : 32
Enter month : 3
Enter the year : 2025
Enter a valid no of days
PS E:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f21.c -o f21; .\f21
Enter the date : 25
Enter month : 3
Enter the year : 2025
25-3-2025 is  a valid date

```

---

## 22 

```c

OUTPUTS 



```
---



## 23. 

```c

// 23. Write a program to calculate area and perimeter of rectangle ?


#include <stdio.h>

int main() {
    int l, b;

    printf("Enter the length of rectangle : ");
    scanf("%d", &l);

    printf("Enter the breath of rectangle : ");
    scanf("%d", &b);

    printf("Area of rectangle is : %d", l*b);
    printf("\nPerimeter of rectangle is :  %d", (l+b)*2);

    return 0;
}


OUTPUTS

PS E:\dx\Coding\C_4205_BCA\source\1_decision_control_structure> gcc f23.c -o f23; .\f23
Enter the length of rectangle : 232
Enter the breath of rectangle : 34
Area of rectangle is : 7888
Perimeter of rectangle is :  532


```



----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---