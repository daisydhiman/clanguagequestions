// 13. Enter three numbers from users and tell which is greater ?

#include <stdio.h>

int main() {
    int a, b, c;

    printf("Enter first number : ");
    scanf("%d", &a);

    printf("Enter second number : ");
    scanf("%d", &b);

    printf("Enter third number : ");
    scanf("%d", &c);

    if (a > b && a > c)
        printf("First number is greater\n");
    else if (b > a && b > c)
        printf("Second number is greater\n");
    else
        printf("Third number is greater\n");

    return 0;
}
