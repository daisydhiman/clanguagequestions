// 23. Write a program to calculate area and perimeter of rectangle ?


#include <stdio.h>

int main() {
    int l, b;

    printf("Enter the length of rectangle : ");
    scanf("%d", &l);

    printf("Enter the breath of rectangle : ");
    scanf("%d", &b);

    printf("Area of rectangle is : %d", l*b);
    printf("\nPerimeter of rectangle is :  %d", (l+b)*2);

    return 0;
}
