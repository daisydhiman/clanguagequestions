// 8. Enter a number from the user 
// if the number is negative then square the number and if it is positive then increment the number 20 times ?

#include <stdio.h>

int main() {
    int a;
    printf("Enter the  number : ");
    scanf("%d", &a);

    if (a < 0)
        printf("Number is -ve ,  Square :  %d\n", a * a);
    else
        printf("Number is +ve , after incrementing 20 times : %d\n", a + 20);

    return 0;
}
