// 16. Enter two characters from user and check both are same or not, 
// if not same then find out difference between them ?

#include <stdio.h>
#include <conio.h>

int main() {
    char a, b;

    printf("Enter first character : ");
    a = getche();

    printf("\nEnter second character : ");
    b = getche();

    if (a == b)
        printf("\nBoth are same");
    else
        printf("\nBoth are different, difference is : %d", a - b);

    return 0;
}
