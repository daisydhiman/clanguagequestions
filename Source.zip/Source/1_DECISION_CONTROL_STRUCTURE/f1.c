// 1. Write a program to enter the number from the user and check it is positive or negative or 0 (zero) ?

# include <stdio.h>

int main(){
    int a;
    printf("Enter the number :");
    scanf("%d",&a);

    a==0 ? printf("The number is ZERO") : a>0 ? printf("The number is +ve ") : printf("The number is -ve") ; 

    return 0;
}