//2. Enter a number from user and check it is odd or even ?

#include <stdio.h>

int main(){
    int a;
    printf("Enter the number :");
    scanf("%d",&a);
    
    a%2==0 ? printf("The number is EVEN") : printf("The number is ODD");

    return 0; 
}