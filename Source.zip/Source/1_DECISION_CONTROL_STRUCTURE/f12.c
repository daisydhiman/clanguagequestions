// 12. Enter a four characters from users and check they are equal or not ?

#include <stdio.h>

int main() {
    char a, b, c, d;

    printf("Enter 1st character : ");
    scanf(" %c", &a);

    printf("Enter 2nd character : ");
    scanf(" %c", &b);

    printf("Enter 3rd character : ");
    scanf(" %c", &c);

    printf("Enter 4th character : ");
    scanf(" %c", &d);

    if (a == b && b == c && c == d)
        printf("All characters are equal\n");
    else
        printf("All characters are not equal\n");

    return 0;
}
