// 9. Enter the number from the user it the number is negative or positive and find out of that number ?

#include <stdio.h>

int main() {
    int a;
    printf("Enter the number : ");
    scanf("%d", &a);

    if (a > 0)
        printf("%d is a positive number\n", a);
    else if (a < 0)
        printf("%d is a negative number\n", a);
    else
        printf("The number is zero\n");


    return 0;
}
