// 3. Enter a number from the user and check that it is of 1 digit or 2 digit or 3 digit or 4 digit or 5 digit ?

#include <stdio.h>

int main() {
    int n;
    printf("Enter the number : ");
    scanf("%d", &n);

    if (n < 0)
        n = -n;  

    if (n >= 0 && n <= 9)
        printf("It is a 1-digit number\n");
    else if (n >= 10 && n <= 99)
        printf("It is a 2-digit number\n");
    else if (n >= 100 && n <= 999)
        printf("It is a 3-digit number\n");
    else if (n >= 1000 && n <= 9999)
        printf("It is a 4-digit number\n");
    else if (n >= 10000 && n <= 99999)
        printf("It is a 5-digit number\n");
    else
        printf("It is more than 5 digits\n");

    return 0;
}
