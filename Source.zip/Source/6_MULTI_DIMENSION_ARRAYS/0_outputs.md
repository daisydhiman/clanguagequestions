# FUNCTIONS 
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
// 1. Enter the four number from user and print it into matrix


#include <stdio.h>
int main(){
    int a[2][2];
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number : ");
        scanf("%d",&a[i][j]);}
    }

    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }


    return 0;
}

OUTPUT


PS D:\dx\Coding\C_4205_BCA\source\6_multi_dimension_arrays> gcc f1.c -o f1; .\f1       
Enter the number : 4
Enter the number : 5
Enter the number : 6
Enter the number : 3
4 5 
6 3

```

---

## 2. 
```c
// 2. Enter the matrix from and transpose them ?

#include <stdio.h>

int main() {
    int a[10][10], transpose[10][10];
    int r, c;

    printf("Enter number of rows : ");
    scanf("%d", &r);
    printf("Enter the number of colunns : ");
    scanf("%d",&c);

    printf("Enter elements of matrix :\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%d", &a[i][j]);
        }
    }


    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            transpose[j][i] = a[i][j];
        }
    }

    printf("\nOriginal Matrix :\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }

    printf("\nTranspose matrix :\n");
    for (int i = 0; i < c; i++) {
        for (int j = 0; j < r; j++) {
            printf("%d ", transpose[i][j]);
        }
        printf("\n");
    }

    return 0;
}


OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\6_multi_dimension_arrays> gcc f2.c -o f2; .\f2
Enter number of rows : 2
Enter the number of colunns : 3
Enter elements of matrix :
1 2 345
67 8 9 

Original Matrix :
1 2 345
67 8 9

Transpose matrix :
1 67
2 8
345 9

```

---

## 3.
```c
/// 3. Enter 2 matrix from user and add them ?


#include <stdio.h>
int main(){
    int mat1[2][2],mat2[2][2];

    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  1 : ");
        scanf("%d",&mat1[i][j]);}
    }
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  2 : ");
        scanf("%d",&mat2[i][j]);}
    }


    // adding the matrices
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

            mat1[i][j]+=mat2[i][j];}

    }

    printf("\nSUM of two matrices :\n");
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){
            printf("%d ",mat1[i][j]);
        }
        printf("\n");
    }




    return 0;
    }

OUTPUT 
PS D:\dx\Coding\C_4205_BCA\source\6_multi_dimension_arrays> gcc f3.c -o f3; .\f3
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  2 : 2
Enter the number in MATRICE  2 : 2
Enter the number in MATRICE  2 : 2
Enter the number in MATRICE  2 : 2

SUM of two matrices :
4 4
4 4

```
---

## 4. 
```c
// 4. Enter 2 matrix from user and subtract them ?



#include <stdio.h>
int main(){
    int mat1[2][2],mat2[2][2];

    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  1 : ");
        scanf("%d",&mat1[i][j]);}
    }
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  2 : ");
        scanf("%d",&mat2[i][j]);}
    }


    // subtracting  the matrices
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

            mat1[i][j]-=mat2[i][j];}

    }

    printf("\nDIFFERERNCE  of two matrices :\n");
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){
            printf("%d ",mat1[i][j]);
        }
        printf("\n");
    }




    return 0;
    }


OUTPUT 


PS D:\dx\Coding\C_4205_BCA\source\6_multi_dimension_arrays> gcc f4.c -o f4; .\f4
Enter the number in MATRICE  1 : 3
Enter the number in MATRICE  1 : 3
Enter the number in MATRICE  1 : 3
Enter the number in MATRICE  1 : 3
Enter the number in MATRICE  2 : 5
Enter the number in MATRICE  2 :   
5
Enter the number in MATRICE  2 : 5
Enter the number in MATRICE  2 : 5

DIFFERERNCE  of two matrices :
-2 -2
-2 -2

```

---

## 5 .

```c
// 5. Enter 2 matrix from user and multiply them ?




#include <stdio.h>
int main(){
    int mat1[2][2],mat2[2][2],result[2][2]={0};

    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  1 : ");
        scanf("%d",&mat1[i][j]);}
    }
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  2 : ");
        scanf("%d",&mat2[i][j]);}
    }


    // multiplting

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 2; k++) {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }

    printf("\nMatrice multiplication   of two matrices :\n");
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){
            printf("%d ",result[i][j]);
        }
        printf("\n");
    }




    return 0;
    }

OUTPUT

PS D:\dx\Coding\C_4205_BCA\source\6_multi_dimension_arrays> gcc f5.c -o f5; .\f5
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  1 : 2
Enter the number in MATRICE  2 : 2
Enter the number in MATRICE  2 : 2
Enter the number in MATRICE  2 : 2
Enter the number in MATRICE  2 : 2

Matrice multiplication   of two matrices :
8 8
8 8 

```


----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---