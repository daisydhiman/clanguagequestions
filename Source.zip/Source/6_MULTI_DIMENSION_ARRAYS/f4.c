// 4. Enter 2 matrix from user and subtract them ?



#include <stdio.h>
int main(){
    int mat1[2][2],mat2[2][2];

    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  1 : ");
        scanf("%d",&mat1[i][j]);}
    }
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

        printf("Enter the number in MATRICE  2 : ");
        scanf("%d",&mat2[i][j]);}
    }


    // subtracting  the matrices
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){

            mat1[i][j]-=mat2[i][j];}

    }

    printf("\nDIFFERERNCE  of two matrices :\n");
    for (int i=0; i<2 ;i++){
        for (int j=0 ; j<2 ; j++){
            printf("%d ",mat1[i][j]);
        }
        printf("\n");
    }




    return 0;
    }