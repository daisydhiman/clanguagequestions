// 1. Write a program print the pattern on the screen i.e. ? 11111 11111 11111

#include <stdio.h>

int main(){
    int a;
    printf("enter the number : ");
    scanf("%d",&a);

    for (int i=1 ; i<=a ; i++){
        for (int j=1 ; j<=a+2 ; j++){
        printf("1");}
        printf(" ");

    }


    return 0;
}