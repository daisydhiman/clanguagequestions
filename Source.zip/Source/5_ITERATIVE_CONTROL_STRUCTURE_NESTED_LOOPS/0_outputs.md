# SINGLE DIMENSION ARRAYSS
>  Daisy Dhiman BCA 4205/25 SEC A
---
## 1 . 
```c
/// 1. Write a program print the pattern on the screen i.e. ? 11111 11111 11111

#include <stdio.h>

int main(){
    int a;
    printf("enter the number : ");
    scanf("%d",&a);

    for (int i=1 ; i<=a ; i++){
        for (int j=1 ; j<=a+2 ; j++){
        printf("1");}
        printf(" ");

    }


    return 0;
}

OUTPUT 

PS D:\dx\Coding\C_4205_BCA\source\5_iterative_control_structure_nested_loops> gcc f1.c -o f1; .\f1
enter the number : 3
11111 11111 11111

```

---


----
----
----
 
 >Daisy Dhiman BCA 4205/25 SEC A

 ----
 ---
 ---